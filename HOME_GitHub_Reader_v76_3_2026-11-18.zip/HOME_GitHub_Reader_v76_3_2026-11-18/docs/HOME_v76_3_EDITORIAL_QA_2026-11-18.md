# HOME v76.3 — final editorial recheck, JCP-2026 v3.3 §0.1–0.7

**Date:** 18 November 2026  
**Scope:** strictly notation, typographic integrity, equation/index layout, internal numbering and cross-references, bibliography, PDF export, reproducibility ZIP. No desk-reject prediction or new scientific review.

## Completed repairs

1. Verified source-based repairs of substantive notation: `3^6=729` and `2^3+2^3-1=15` (K4 cochain census); duration-descent `T_tilde` → native Word math with one consistent `\widetilde T`; `N₀^(h)`, physical congruence, indexed order symbols; calibrated interval arrows/inequalities; `E_{ij}^{(m)}`, matrix dimensions, transposes; spectral `\sqrt{}`/infinity; H4 anchor bounds.
2. 49 Chapter-12 roadmap subsections renumbered from historical 12.8–12.56 to continuous **12.1–12.49**; three affected internal text references updated. Historical T-series IDs, including the separate O3 numbering boundary, are unchanged.
3. Table 3 continuation row now repeats its column headings across the 3-page table. No table data were changed.
4. Unified US-English *relabeling*. Bibliography was conservatively typeset at 10 pt (reference text unchanged) to avoid an orphan final page; the main body font and layout were not compressed.
5. Original v76.2 was not modified. HOME d=4 / DG / O3–O6 separation and conditional-H4 status were retained.

## Automated checks of the final PDF and DOCX

| Test | Result |
| --- | --- |
| Rendered PDF pages | 162 |
| PDF navigation bookmarks | 173 |
| PDF GitHub links | [(159, 'https://github.com/alexandermtishin-art/HOME')] |
| Chapter-12 headings | 49/49 sequential |
| Literature entries | 88/88 |
| First-citation order | 1–88 sequential |
| Blank PDF pages | 0 |
| Text blocks outside page | 0 |
| DOCX tracked changes/comments | none detected |

## Important limitations

- The editorial review does not certify every theorem or every external DOI. OMML and detailed text fragments should be checked against the final PDF (not only PDF text extraction, whose layout order can differ from printed equations). High-risk pages, all existing source figures/tables, the section-12 transition and H4 appendix were inspected after render. 
- This is a **local release candidate**, not a claim that the v76.3 files are already deposited at a fixed GitHub release/commit. The current public repository is https://github.com/alexandermtishin-art/HOME.
- The apparatus and event-count synthetic controls do not establish a physical Nature pass for HOME.
