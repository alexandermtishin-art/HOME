# HOME v76.3 preprint release checklist

- [x] Preserve v76 source; write a distinct v76.1 manuscript.
- [x] Integrate exact-support correction in §§4.3.1, 12.6 and Table 1.
- [x] Use HOME-C01/C02 rather than O3-reserved T1353/T1354 for two new synthetic controls.
- [x] Describe the B3 / Pre-UPO matrix as an internally pre-specified, preregistration-ready proposal, **not** an externally registered or completed experiment.
- [x] Keep conditional H4 duration and anchor-drift results in Appendix A; no physical pass claimed.
- [x] Rebuild DOCX, PDF, verifier and SHA-256 inventory.
- [x] Confirm dedicated public HOME GitHub repository URL: https://github.com/alexandermtishin-art/HOME.
- [ ] Upload this **v76.3** bundle to the HOME repository, record an immutable tag/commit or release, and only then add such a tag or DOI to deposited manuscripts (if permitted).
- [ ] Publicly deposit the preprint (e.g. preprint server); obtain permanent record/DOI.

## Scientific separation
This bundle contains HOME only. Independent DG and d=4 are cited only as external inputs with explicit limitations. Separate O3–O6 material is excluded, including its T1353+ ledger.

## Limitations
The main Nature-Candidate Gate and HOME-specific Novel-Prediction Gate remain open. Simulations verify test logic, not foundational physics. The original source of Appendix A.1 (N.7) was not independently audited as part of this publication pack; its claim remains explicitly conditional and non-premissory.

- [x] JCP v3.3 §0.1–0.7 editorial pass on v76.3 (see docs/HOME_v76_3_JCP33_EDITORIAL_QA_2026-11-18.md).
