# HOME v75 — post-freeze exact-support clarification
**Scope:** logical correction imported into the HOME research record after the 28 September v75 manuscript was frozen. This is not a rewritten manuscript.

## Exact support
Let physical equivalence be determined by the **complete admissible contextual-response profile** of a process. Assume that replacement/removal interventions on primitive participants are included in the declared context repertoire, with support defined by sensitivity under those interventions.

Then operational support is constant on the resulting complete physical classes:

\[
e_1 \sim_{\mathrm{HOME}} e_2
\quad\Longrightarrow\quad
\mathrm{supp}(e_1)=\mathrm{supp}(e_2).
\]

Thus an exact operational support can be assigned to each such class, even if the support is infinite. **Finite primitive arity, a finite primitive envelope, ACC refinement, event atomicity, and a finite complete channel quotient are not prerequisites for this support descent.**

## Critical distinction within HOME
The support of **every** admissible nonfactorizing process does **not** automatically denote a single physical interaction episode. A sequential composition can be nonfactorizing on the union of participants while its physical realization contains multiple successive interactions.

Consequently distinguish:
1. Exact support of a physical HOME process class.
2. The family of supports of all admissible nonfactorizing joint processes (interaction capacity).
3. The class of physically singled-out one-layer/one-episode occurrences, **if** one is independently identified.

Only (1) follows conditionally from the complete support-sensitive response semantics. The existence or uniqueness of (3) has **not** been derived from HOME Core.

## Status of the earlier finiteness argument
A finite-envelope stabilization lemma in v75 may remain a *sufficient* condition for a particular stabilization assertion where its premises apply. It must not be read as a *necessary* prerequisite for exact operational support or as a proof of unique physical interaction segmentation.

No new HOME physical postulate is adopted by this clarification.

**v76.3 numbering note.** Old §12.13 has become §12.6 in the publication roadmap; the scientific content is unchanged.
