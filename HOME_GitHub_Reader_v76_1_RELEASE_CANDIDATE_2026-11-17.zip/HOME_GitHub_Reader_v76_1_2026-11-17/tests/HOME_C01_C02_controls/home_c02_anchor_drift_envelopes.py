"""Randomized check of the anchor-drift envelope bound of Appendix A.2:
for an L-Lipschitz drift observed at anchors with bracket error r, the McShane/Whitney envelopes contain the true
drift and their half-width inside the anchor span is at most r + L h / 2 (h = largest anchor gap)."""
import numpy as np, json
rng=np.random.default_rng(20261116); trials=2000; contain=0; bound=0; worst=-1e9
for _ in range(trials):
    L=rng.uniform(1,10); r=rng.uniform(.1,1); n=int(rng.integers(2,30)); t=np.sort(rng.uniform(0,1,n))
    x=np.linspace(0,1,2001); g=np.concatenate([[0],np.cumsum(rng.uniform(-L,L,2000))/2000]); f=lambda s:np.interp(s,x,g)
    lo_a=f(t)-rng.uniform(0,r,n); hi_a=f(t)+rng.uniform(0,r,n); s=np.linspace(0,1,500)
    lo=np.max(lo_a[:,None]-L*abs(s[None]-t[:,None]),0); hi=np.min(hi_a[:,None]+L*abs(s[None]-t[:,None]),0)
    contain+=bool(((lo<=f(s)+1e-9)&(f(s)<=hi+1e-9)).all())
    m=(s>=t[0])&(s<=t[-1]); h=np.max(np.diff(t)); w=((hi-lo)/2)[m].max()
    bound+=bool(w<=r+L*h/2+1e-9); worst=max(worst,float(w-(r+L*h/2)))
ctrl=[{"control":"envelopes contain the true drift in all trials","pass":contain==trials},
      {"control":"half-width bound r + L h / 2 holds in all trials","pass":bound==trials}]
print(json.dumps({"suite":"HOME-C02 anchor-drift envelopes","trials":trials,"max_excess_over_bound":round(worst,12),"controls":ctrl,
 "summary":{"total":2,"passed":sum(c["pass"] for c in ctrl)}},indent=1,sort_keys=True))
