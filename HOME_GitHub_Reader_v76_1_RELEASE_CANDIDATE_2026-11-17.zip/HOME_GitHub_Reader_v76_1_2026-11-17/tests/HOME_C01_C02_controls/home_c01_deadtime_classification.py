"""Event-level check of the dead-time classification for count-terminated edges.
Latent time is used only to generate hostile event streams; the edge datum is a count ratio
in a bracket closed on the m-th recorded reference event."""
import numpy as np, json
rng=np.random.default_rng(20261116)
lam=np.array([1.0,1.63,0.79]); names='ABC'
edges=[(0,1,2),(1,2,0),(2,0,1)]  # (i,j,ref): AB until m-th C, BC until m-th A, CA until m-th B
def stream(rate,n): return np.cumsum(rng.exponential(1/rate,n))
def nonpar(t,tau):
    if tau==0: return t
    out=[];last=-1e9
    for x in t:
        if x-last>=tau: out.append(x);last=x
    return np.array(out)
def edge_counts(i,j,k,m,mode,tau):
    n=int(m*max(lam)/lam[k]*1.3)+2000
    t=[stream(lam[q],int(n*lam[q]/max(lam))+2000) for q in range(3)]
    if mode=='node':            # each stream has its own detector with its own dead time
        rec={q:nonpar(t[q],tau[q]) for q in (i,j,k)}
    elif mode=='shared':        # i and j share one type-blind non-paralyzable front end
        allt=np.concatenate([t[i],t[j]]);lab=np.concatenate([np.zeros(len(t[i])),np.ones(len(t[j]))])
        o=np.argsort(allt);allt=allt[o];lab=lab[o]
        keep=[];last=-1e9
        for idx,x in enumerate(allt):
            if x-last>=tau: keep.append(idx);last=x
        keep=np.array(keep);rec={i:allt[keep][lab[keep]==0],j:allt[keep][lab[keep]==1],k:t[k]}
    elif mode=='shared_par':    # type-blind paralyzable: recorded iff no event of either type in preceding tau
        allt=np.concatenate([t[i],t[j]]);lab=np.concatenate([np.zeros(len(t[i])),np.ones(len(t[j]))])
        o=np.argsort(allt);allt=allt[o];lab=lab[o]
        ok=np.concatenate([[True],np.diff(allt)>=tau])
        rec={i:allt[ok&(lab==0)],j:allt[ok&(lab==1)],k:t[k]}
    elif mode=='priority':      # winner w vetoes loser events arriving within tau after a winner event
        w,l=tau['win'](i,j)
        pos=np.searchsorted(t[w],t[l])           # index of first winner event after each loser event
        prev=np.where(pos>0,t[w][np.maximum(pos-1,0)],-1e9)
        rec={w:t[w],l:t[l][t[l]-prev>=tau['tau']],k:t[k]}
    tend=rec[k][m-1]
    return np.sum(rec[i]<=tend),np.sum(rec[j]<=tend)
def run(mode,tau,m=400000):
    b=[]
    for (i,j,k) in edges:
        ni,nj=edge_counts(i,j,k,m,mode,tau);b.append(np.log(ni/nj))
    return np.array(b)
res={}
ideal=np.array([np.log(lam[i]/lam[j]) for i,j,k in edges])
sig=np.sqrt(sum(lam[k]/lam[i]+lam[k]/lam[j] for i,j,k in edges)/400000)
res['sigma_holonomy_m4e5']=float(sig)
# 1 node-local
tau=np.array([0.05,0.12,0.2]); b=run('node',tau)
f=np.log(lam)-np.log(1+lam*tau); pred=np.array([f[i]-f[j] for i,j,k in edges])
res['node']={'holonomy':float(b.sum()),'edge_shift_obs':(b-ideal).round(4).tolist(),'edge_shift_pred':(pred-ideal).round(4).tolist()}
# 2 shared type-blind
for md in ('shared','shared_par'):
    b=run(md,0.15); res[md]={'holonomy':float(b.sum()),'edge_shift_obs':(b-ideal).round(4).tolist()}
# 3 priority
T=0.08
b=run('priority',{'tau':T,'win':lambda i,j:(min(i,j),max(i,j))})   # fixed priority A>B>C
res['priority_fixed']={'holonomy':float(b.sum()),'pred':float(lam[1]*T)}
b=run('priority',{'tau':T,'win':lambda i,j:(i,j)})                 # first-named stream wins on each edge
res['priority_cyclic']={'holonomy':float(b.sum()),'pred':float(lam.sum()*T)}
ctrl=[]
def chk(name,ok): ctrl.append({"control":name,"pass":bool(ok)})
chk("node-local loss: holonomy within 2 sigma of zero",abs(res['node']['holonomy'])<2*sig)
chk("node-local loss: edge shifts match gradient prediction (tol 0.005)",np.allclose(res['node']['edge_shift_obs'],res['node']['edge_shift_pred'],atol=0.005))
chk("shared type-blind non-paralyzable: holonomy within 2 sigma of zero",abs(res['shared']['holonomy'])<2*sig)
chk("shared type-blind paralyzable: holonomy within 2 sigma of zero",abs(res['shared_par']['holonomy'])<2*sig)
chk("shared type-blind: edge shifts below 0.01",max(abs(np.array(res['shared']['edge_shift_obs'])).max(),abs(np.array(res['shared_par']['edge_shift_obs'])).max())<0.01)
chk("fixed priority: holonomy equals lam_B*tau_r within 5 sigma",abs(res['priority_fixed']['holonomy']-res['priority_fixed']['pred'])<5*sig)
chk("cyclic priority: holonomy equals (sum lam)*tau_r within 5 sigma",abs(res['priority_cyclic']['holonomy']-res['priority_cyclic']['pred'])<5*sig)
out={"suite":"HOME-C01 dead-time classification","results":res,"controls":ctrl,"summary":{"total":len(ctrl),"passed":sum(c["pass"] for c in ctrl)}}
print(json.dumps(out,indent=1,sort_keys=True))
