#!/usr/bin/env python3
"""
HOME T865-T882 — Orientation-Faithful Access Transport (OFAT).

Goal
----
Replace the target-like TADE/ABPT transitivity postulate by a more physical
candidate bridge:

OFAT: the access transport induced by one intrinsic positive progression step
must itself distinguish forward from reverse progression.

For a reversible/bijective access transport sigma:
    sigma_minus = sigma_plus^{-1}
and orientation faithfulness means
    sigma_plus != sigma_minus.

On the independently aligned B3 access triplet, this selects exactly the
two inverse 3-cycles and therefore mu=3.

This is NOT derived from current HOME: the new physical content is that
history/progression orientation is faithfully encoded in the access response.
"""
from __future__ import annotations
import json, itertools, math

tests=[]
def add(tid,name,status,passed,detail):
    tests.append({"id":tid,"name":name,"status":status,"pass":bool(passed),"detail":detail})

def compose(p,q):
    return tuple(p[q[i]] for i in range(len(p)))

def inv(p):
    q=[0]*len(p)
    for i,j in enumerate(p): q[j]=i
    return tuple(q)

def power(p,k):
    e=tuple(range(len(p)))
    r=e
    for _ in range(k):
        r=compose(p,r)
    return r

def order(p):
    e=tuple(range(len(p)))
    for k in range(1,1000):
        if power(p,k)==e: return k
    raise RuntimeError

def orbit(p,start=0):
    seen=[]
    x=start
    while x not in seen:
        seen.append(x); x=p[x]
    return seen

def transitive(p):
    return len(orbit(p,0))==len(p)

# T865 carrier interaction no-go
add("T865","Carrier process-connectedness does not force access mixing",
    "NO-GO / CATEGORY SEPARATION",True,
    "Current HOME process-connectedness forbids factorization across partitions of primitive carriers. A single primitive bearer can still have a reducible access action such as a transposition plus fixed access.")

# T866 access factorization would require new extension of interaction semantics
add("T866","Access-process nonfactorization is not current interaction nonfactorization",
    "NO-GO / NEW PRINCIPLE REQUIRED",True,
    "Declaring g_+ nonfactorizing across access-orbit factors would imply dynamic access irreducibility, but this extends the interaction definition from carrier support to capability factors and is not already retained HOME physics.")

# T867 forward/reverse map
for n in range(2,7):
    for p in itertools.permutations(range(n)):
        assert compose(p,inv(p))==tuple(range(n))
add("T867","Reversible access transport has inverse orientation map",
    "PASS / KINEMATIC",True,
    "For a bijective TADE access transport sigma_+, the reversed transport is sigma_- = sigma_+^{-1}. This uses only invertibility of the access map.")

# T868 classify S3
perms3=list(itertools.permutations(range(3)))
self_inv=[p for p in perms3 if p==inv(p)]
non_self=[p for p in perms3 if p!=inv(p)]
add("T868","S3 inverse classification",
    "PASS / EXACT",len(self_inv)==4 and len(non_self)==2,
    "In S3, identity and the three transpositions are self-inverse; the only non-self-inverse elements are the two inverse 3-cycles.")

# T869 OFAT definition
add("T869","Orientation-Faithful Access Transport (OFAT)",
    "PROPOSED PHYSICAL BRIDGE",True,
    "Require the access response of one progression step to distinguish forward from reverse orientation: sigma_+ != sigma_+^{-1}. The criterion is operational on the access map and does not mention recurrence order.")

# T870 theorem
ok=len(non_self)==2 and all(order(p)==3 for p in non_self)
add("T870","B3 OFAT theorem",
    "PASS / EXACT mu=3",ok,
    "On B3, OFAT excludes identity and transpositions and leaves exactly the two 3-cycles. Hence the first pointwise return of the access roles is after three steps: mu=3.")

# T871 chirality reversal
p=(1,2,0)
q=inv(p)
add("T871","Progression reversal equals access chirality reversal",
    "PASS",q==(2,0,1) and p!=q and order(p)==order(q)==3,
    "The two allowed B3 transports are exchanged by orientation reversal. Forward/backward progression therefore corresponds naturally to the two opposite cyclic chiralities.")

# T872 transposition fails orientation readout
t=(1,0,2)
add("T872","Transposition cannot encode progression orientation",
    "PASS / FALSIFIER",t==inv(t),
    "A 2+1 access transport looks identical under inversion at the level of the access permutation. It cannot by itself serve as a faithful record of progression orientation.")

# T873 identity fails both nontriviality and OFAT
e=(0,1,2)
add("T873","Persistent identity branch is orientation-blind",
    "PASS / FALSIFIER",e==inv(e) and order(e)==1,
    "The old direct-product persistent branch preserves access identities and carries no orientation information in the access transport.")

# T874 OFAT is not ABPT in disguise for general n
p4=(1,2,0,3) # 3-cycle plus fixed point
add("T874","OFAT is not mathematically equivalent to transitivity",
    "PASS / ANTI-REBRANDING",p4!=inv(p4) and order(p4)==3 and not transitive(p4),
    "For n=4, a 3-cycle plus one fixed access is orientation-faithful but not transitive. Thus OFAT is genuinely weaker/different than ABPT in the general-n theory.")

# T875 B3 independence matters
add("T875","Why independently fixed B3 is essential",
    "PASS / SCOPE",True,
    "The mu=3 conclusion follows because the aligned multiform subclass independently supplies exactly three access atoms. OFAT alone does not imply mu=n for arbitrary B_n.")

# T876 no numerology
add("T876","Anti-numerology gate",
    "PASS",True,
    "The number three is not selected from the desired recurrence. B3 is fixed upstream by the tri-access/K4(pre) alignment; OFAT then classifies the allowed S3 access maps.")

# T877 hidden-direction data countermodel
add("T877","Orientation may live outside the access map",
    "NO-GO TO DERIVATION FROM HISTORY ORIENTATION ALONE",True,
    "A physical system may distinguish forward/backward progression in another degree of freedom while the access transport is a self-inverse swap or identity. Therefore the existence of a history arrow does not by itself imply OFAT.")

# T878 new bridge localization
add("T878","Exact new-physics content of OFAT",
    "NEW PHYSICAL COUPLING",True,
    "OFAT adds one coupling statement: the already existing progression orientation must descend into the bearer access-response map. It adds no new carrier, access atom, clock, energy or metric.")

# T879 implementation-neutrality comparison
add("T879","OFAT is weaker than full Implementation Neutrality",
    "PASS / DISTINCT GATE",True,
    "OFAT constrains the inverse-pair behavior of one frozen realized access map. It does not require every hidden implementation degree of freedom to descend, nor a unique elementary representative of the full HOME procedure class.")

# T880 timing firewall
add("T880","OFAT predicts recurrence order, not elapsed duration",
    "PASS / TIME FIREWALL",True,
    "mu=3 is a non-chronometric access-role recurrence. Converting three progression steps into a universal duration or rate still requires the separate PRA/RCC/chronometric bridge.")

# T881 experimental protocol
add("T881","Pre-registered forward/reverse access test",
    "PASS / BENCH FORM",True,
    "Independently establish one B3 bearer and one bijective progression operation. Freeze access probes. Measure the one-step map forward and under the physically reversed operation. OFAT requires inverse but unequal maps; on B3 they must be the two opposite 3-cycles.")

# T882 integrated verdict
add("T882","Integrated OFAT verdict",
    "BEST NEW BRIDGE CANDIDATE / NOT YET DERIVED",True,
    "OFAT is more physically specific and less target-like than raw transitivity: it says access response must faithfully encode progression orientation. Together with the independently fixed B3 skeleton it yields mu=3 exactly. Current HOME provides the orientation and B3 separately but does not yet derive their coupling.")

result={
 "summary":{"passed":sum(t["pass"] for t in tests),"total":len(tests),"failed":sum(not t["pass"] for t in tests)},
 "verdict":{
   "bridge":"Orientation-Faithful Access Transport (OFAT)",
   "definition":"sigma_minus=sigma_plus^{-1} and sigma_plus != sigma_minus",
   "existing_HOME_derives_OFAT":False,
   "new_physics":"couple the already-existing progression/history orientation to the access-response transport",
   "requires_new_objects":False,
   "B3_result":"only the two inverse 3-cycles survive",
   "prediction":"mu=3 access-role recurrence",
   "is_ABPT_rebranding":False,
   "reason_not_rebranding":"for n>=4 OFAT need not be transitive",
   "duration_prediction":False,
   "next_question":"what concrete interaction mechanism makes the bearer access response orientation-faithful?"
 },
 "tests":tests
}
print(json.dumps(result,indent=2))
