#!/usr/bin/env python3
"""
HOME T897-T914 — Orientation-Response Detectability (ORD).

Purpose
-------
Ask whether existing HOME completeness/alignment principles already force
OFAT/CAC, without adding a new postulate.

Result
------
They do not.

What *is* available conditionally is a weaker statement:
if forward and reverse procedures are physically distinct in the retained
procedure/action language, and the declared HOME response language is
response-separating for that distinction, then some HOME response context
must distinguish them.

This does not imply that their induced permutation on the B3 access atoms is
different.  The orientation witness can live in another response datum.
"""
from __future__ import annotations
import json, itertools

tests=[]
def add(tid,name,status,passed,detail):
    tests.append({"id":tid,"name":name,"status":status,"pass":bool(passed),"detail":detail})

def inv(p):
    q=[0]*len(p)
    for i,j in enumerate(p): q[j]=i
    return tuple(q)

# T897 history orientation vs reversible pair
add("T897","Activated history orientation does not supply a reverse operation",
    "PASS / SCOPE",True,
    "A strict complete-history extension defines forward orientation. It does not by itself guarantee that an inverse physical procedure is admissible or realizable.")

# T898 conditional distinguishability theorem
add("T898","Orientation-Response Detectability (ORD)",
    "CONDITIONAL THEOREM",True,
    "If two realized procedures u_+ and u_- induce distinct retained actions and the declared HOME generated response family is response-separating for that action difference, then at least one HOME context distinguishes their responses.")

# T899 finite countermodel: same access permutation, distinct orientation tag
swap=(1,0,2)
forward={"perm":swap,"tag":+1}
reverse={"perm":swap,"tag":-1}
add("T899","Response distinction can coexist with identical access permutation",
    "NO-GO TO OFAT", forward["perm"]==reverse["perm"] and forward["tag"]!=reverse["tag"],
    "Forward and reverse can be perfectly distinguishable by an orientation-sensitive response tag while inducing the same self-inverse transposition on the three access atoms.")

# T900 all B3 contexts still available
contexts=list(itertools.product([0,1], repeat=3))
add("T900","Full static B3 does not remove the countermodel",
    "NO-GO TO OFAT", len(contexts)==8,
    "All eight independently armable B3 subset contexts can coexist with the T899 countermodel; static access completeness does not force orientation information into the atom permutation.")

# T901 response-separating completeness
add("T901","Response-separating completeness detects orientation somewhere",
    "PASS / WEAKER RESULT",True,
    "If the orientation tag is physically admissible and the generated response language is complete for it, forward/reverse cannot remain HOME-equivalent. Completeness guarantees detectability, not a specific carrier of the distinction.")

# T902 Action Separation scope
add("T902","Action Separation does not choose the access carrier of the distinction",
    "PASS / SCOPE",True,
    "Action Separation says every retained action difference is detected by HOME responses. It does not say that the difference must be represented by the B3 atom permutation rather than another response coordinate.")

# T903 full alignment countermodel if d4 action includes tag
d4_plus=(swap,+1)
d4_minus=(swap,-1)
home_plus=(swap,+1)
home_minus=(swap,-1)
add("T903","Full Procedure-Action Alignment still need not imply OFAT",
    "NO-GO / EXPLICIT COUNTERMODEL",
    d4_plus==home_plus and d4_minus==home_minus and d4_plus!=d4_minus and forward["perm"]==reverse["perm"],
    "If the retained d=4 action itself contains an orientation-sensitive datum in addition to the access permutation, kernel equality/full alignment can hold exactly while sigma_+=sigma_- on B3.")

# T904 if d4 retains only permutation, hidden tag violates implementation neutrality
add("T904","Implementation Neutrality bites only after access-action exhaustion",
    "PASS / CONDITIONAL",True,
    "If the retained downstream action is *defined* to contain only the access permutation, then a hidden HOME orientation tag with the same permutation would violate Implementation Neutrality. But that access-action exhaustion premise is not current HOME.")

# T905 define AAE
add("T905","Access-Action Exhaustion (AAE)",
    "NEW STRONG PREMISE / NOT ADOPTED",True,
    "AAE would assert that, for the progression pair under study, the complete retained physical action is exhausted by the induced automorphism of the access algebra. No additional response/action coordinate may carry orientation.")

# T906 AAE + distinct orientation -> OFAT
add("T906","AAE plus physical forward/reverse distinction implies unequal access maps",
    "PASS / CONDITIONAL LOGIC",True,
    "Under AAE, if forward and reverse are physically distinct complete actions, their access automorphisms must differ. For a reversible B3 transport this becomes sigma_+ != sigma_+^{-1}, i.e. OFAT.")

# T907 AAE is essentially the missing localization premise
add("T907","AAE is not derived by Full Physical Quotient Completeness",
    "NO-GO / DISTINCT GATE",True,
    "Full Physical Quotient Completeness says the generated HOME response language captures all physical response distinctions. It does not identify the entire response quotient with Aut(B3), so it does not imply AAE.")

# T908 complete contextual response can carry scalar/chiral datum
add("T908","Complete contextual-response quotient can be richer than B3 automorphisms",
    "PASS / COUNTERMODEL CLASS",True,
    "The complete response profile may include intensities, phases, records, intermediate-boundary responses or other operational data in addition to which access atom maps to which. Such data can encode orientation without OFAT.")

# T909 no-hidden-generator does not solve response localization
add("T909","No-hidden-positive / PQA does not imply OFAT",
    "NO-GO / CATEGORY SEPARATION",True,
    "Eliminating hidden positive progression directions constrains chronology/progression classes. It does not force the orientation signature of that progression to reside in the B3 access permutation.")

# T910 implementation neutrality not enough unless downstream action chosen
add("T910","Implementation Neutrality is representation-relative",
    "PASS / FIREWALL",True,
    "Implementation Neutrality compares HOME distinctions to a declared retained downstream action. It cannot by itself prove that the physically correct retained action is 'B3 permutation only'.")

# T911 minimal theorem from existing structure
add("T911","Strongest no-new-postulate statement",
    "CONDITIONAL ORD ONLY",True,
    "Existing HOME supports, at most, conditional orientation-response detectability: a physically distinct forward/reverse pair cannot be invisible to a complete response-separating language. The location/form of the witness remains underdetermined.")

# T912 B3 special theorem remains conditional on OFAT/AAE
perms3=list(itertools.permutations(range(3)))
nonself=[p for p in perms3 if p!=inv(p)]
add("T912","B3 group-theory consequence remains exact but conditional",
    "PASS", len(nonself)==2,
    "If one independently establishes that the orientation witness is the B3 automorphism itself, S3 leaves only the two inverse 3-cycles and mu=3. The group theory is exact; the localization premise is the missing physics.")

# T913 experimental implication
add("T913","Broader experiment before OFAT",
    "PASS / NON-POSTULATIONAL PROGRAM",True,
    "A forward/reverse bench experiment should first measure the complete declared response profile, not only the access permutation. If orientation is detected outside the permutation, OFAT is falsified as a universal localization claim while ORD can still hold.")

# T914 integrated verdict
add("T914","Integrated completeness-route verdict",
    "NO DERIVATION OF OFAT / ORD SURVIVES",True,
    "Response completeness, Action Separation, PQA and even full procedure alignment do not force orientation information into the B3 permutation. A new Access-Action Exhaustion/localization premise would be required. Therefore OFAT/CAC remains unadopted; the correct next step is to search for an independently derived reason why the complete physical action should be exhausted by access transport, or to test where orientation actually appears in a concrete bearer.")

result={
 "summary":{"passed":sum(t["pass"] for t in tests),"total":len(tests),"failed":sum(not t["pass"] for t in tests)},
 "verdict":{
   "OFAT_derived_from_existing_HOME":False,
   "strongest_existing_result":"conditional Orientation-Response Detectability (ORD)",
   "ORD":"physically distinct forward/reverse retained actions must differ in at least one complete HOME response under response-separating coverage",
   "why_not_OFAT":"orientation can be encoded in response data other than the B3 atom permutation",
   "full_alignment_sufficient":False,
   "PQA_sufficient":False,
   "missing_extra_premise":"Access-Action Exhaustion (AAE): the complete retained action is exhausted by the B_n automorphism",
   "AAE_status":"new strong premise; not adopted",
   "experimental_next_step":"measure complete forward/reverse response profile and determine empirically where the orientation witness lives"
 },
 "tests":tests
}
print(json.dumps(result,indent=2))
