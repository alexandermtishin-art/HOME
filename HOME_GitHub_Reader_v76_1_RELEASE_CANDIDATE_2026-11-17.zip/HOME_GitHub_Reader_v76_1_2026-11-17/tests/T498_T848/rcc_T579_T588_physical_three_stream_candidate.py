#!/usr/bin/env python3
"""HOME RCC controls T579-T588: minimal concrete physical three-stream bench candidate.

Candidate architecture
----------------------
Three physically distinct event streams A, B, C produce discriminator/counter pulses.
Each pairwise edge is measured directly on its own count-terminated bracket:

  AB: count A/B until the m-th C reference pulse
  BC: count B/C until the m-th A reference pulse
  CA: count C/A until the m-th B reference pulse

No elapsed-time value is an input to the ideal measurement map. The same physical pulse
fan-out may be sent to two independent counter/electronics banks to implement the minimal
Instrument-Descent replication found in T569-T578. This is a bench-candidate architecture,
not a claim that a fundamental HOME Nature candidate has been identified.

Latent time appears only in hostile simulations that generate event streams. The tested
measurement rule uses event order/counts and reference-event termination only.
"""
from __future__ import annotations
import json, math
import numpy as np
import sympy as sp

rng = np.random.default_rng(20260924)
tests = []

def add(i, name, ok, detail):
    tests.append({"id": i, "name": name, "pass": bool(ok), "detail": detail})

def poisson_count_ratio(m, rates, edge, ntr=2500, efficiency=None):
    """Gamma-Poisson identity for a bracket terminated by m events of the reference stream."""
    i, j, ref = edge
    if efficiency is None:
        efficiency = np.ones(3)
    T = rng.gamma(shape=m, scale=1.0/(rates[ref]*efficiency[ref]), size=ntr)
    ni = rng.poisson(rates[i]*efficiency[i]*T)
    nj = rng.poisson(rates[j]*efficiency[j]*T)
    mask = (ni > 0) & (nj > 0)
    return ni[mask] / nj[mask]

def cycle_samples(m, rates, ntr=2500, efficiency=None):
    edges = [(0,1,2),(1,2,0),(2,0,1)]
    if efficiency is None:
        efficiency=np.ones(3)
    out=[]
    for _ in range(ntr):
        s=0.0
        good=True
        for edge in edges:
            i,j,ref=edge
            T=float(rng.gamma(shape=m, scale=1.0/(rates[ref]*efficiency[ref])))
            ni=int(rng.poisson(rates[i]*efficiency[i]*T))
            nj=int(rng.poisson(rates[j]*efficiency[j]*T))
            if ni<=0 or nj<=0:
                good=False; break
            s += math.log(ni/nj)
        if good: out.append(s)
    return np.asarray(out)

# Candidate definition: edge-specific physical brackets; no scalar-time argument.
edges = {
    "AB": {"count": ("A","B"), "stop": ("C","mth_event")},
    "BC": {"count": ("B","C"), "stop": ("A","mth_event")},
    "CA": {"count": ("C","A"), "stop": ("B","mth_event")},
}

# T579 — syntactic/operational prechronometric gate.
forbidden={"time","duration","timestamp","frequency","clock_period"}
deps=set()
for spec in edges.values():
    deps.update(spec["count"]); deps.update(spec["stop"])
add("T579",
    "cyclic third-stream monitor rule defines all three edges without a scalar-time input",
    forbidden.isdisjoint(deps) and set(edges)=={"AB","BC","CA"},
    f"measurement dependencies={sorted(deps)}; forbidden scalar-time inputs absent.")

# T580 — pairwise edges are not algebraically forced to close because each uses its own bracket.
rates=np.array([1.0,1.63,0.79])
finite=[]
for e in [(0,1,2),(1,2,0),(2,0,1)]:
    rr=poisson_count_ratio(40,rates,e,ntr=1)
    finite.append(float(rr[0]))
prod=float(np.prod(finite)); logH=math.log(prod)
add("T580",
    "independently count-terminated pairwise brackets do not impose tautological cycle closure",
    abs(logH)>1e-3,
    f"one finite raw cycle gives ratios={finite}, product={prod:.6f}, logH={logH:.4f}.")

# T581 — candidate-specific refinement under stationary control.
rms=[]
for m in (100,1000,10000):
    x=cycle_samples(m,rates,ntr=2200)
    rms.append(float(np.sqrt(np.mean(x*x))))
add("T581",
    "cyclic third-stream count brackets recover stationary closure under event-count refinement",
    rms[2] < rms[1] < rms[0] and rms[2] < 0.05,
    f"RMS log holonomy m=100,1000,10000: {rms}.")

# T582 — common pulse fan-out supplies identical physical bracket boundaries to two counter banks.
# We model the reference pulse labels, not elapsed times: both banks stop on the same m-th label.
m=500
ref_labels=np.arange(1,2001)
stop1=int(ref_labels[m-1]); stop2=int(ref_labels[m-1])
accepted1=ref_labels[ref_labels<=stop1]
accepted2=ref_labels[ref_labels<=stop2]
add("T582",
    "shared reference-pulse fan-out gives two counter banks the same event-defined bracket",
    stop1==stop2 and np.array_equal(accepted1,accepted2) and len(accepted1)==m,
    f"both banks terminate on reference-event label {stop1} with exactly {m} accepted reference pulses.")

# T583 — exact rank of the concrete two-bank triangle.
B=sp.Matrix([[1,-1,0],[0,1,-1],[-1,0,1]])
B2=sp.Matrix.vstack(B,B)
A=sp.zeros(6,2)
for r in range(2):
    for e in range(3): A[3*r+e,r]=1
post=6-B2.row_join(A).rank()
add("T583",
    "two full counter-bank realizations leave positive post-apparatus-main falsifiability",
    post==2,
    f"concrete candidate d_test=6-rank([B_rep A_main])={post}.")

# T584 — electronics/detection efficiency can be cycle-blind but same-edge visible.
eff1=np.array([1.0,1.0,1.0])
eff2=np.array([0.91,1.04,1.08])
shift=np.array([
    math.log((eff2[0]/eff2[1])/(eff1[0]/eff1[1])),
    math.log((eff2[1]/eff2[2])/(eff1[1]/eff1[2])),
    math.log((eff2[2]/eff2[0])/(eff1[2]/eff1[0])),
])
add("T584",
    "counter-bank channel efficiencies can be RCC-cycle blind while remaining visible to same-edge Instrument Descent",
    abs(float(shift.sum()))<1e-12 and float(np.max(np.abs(shift)))>0.05,
    f"same-edge log shifts={shift.tolist()}, cycle sum={shift.sum():.3e}.")

# T585 — monitor-only semantics must not be weakened to an OR(time,count) accepted boundary.
# This is a candidate design firewall matching the T561-T568 hardware-semantics result.
monitor_only={"accept_on":"mth_reference_event", "timeout":"censor_only"}
hybrid={"accept_on":"first_of_time_or_count", "timeout":"accepted_boundary"}
valid=(monitor_only["accept_on"]=="mth_reference_event" and monitor_only["timeout"]=="censor_only" and hybrid["accept_on"]!="mth_reference_event")
add("T585",
    "bench candidate requires monitor-only accepted termination; time-or-count acceptance is rejected",
    valid,
    "accepted edge is emitted only after the m-th reference event; a watchdog may censor but may not define an accepted boundary.")

# T586 — sequential acquisition under stream-specific drift can fake persistent holonomy.
# Use log-linear latent rates: log lambda_i(t)=log lambda_i(0)+g_i t.
g=np.array([0.08,-0.04,0.03])
loglam0=np.log(rates)
seq_times=np.array([-1.0,0.0,1.0])
seq_edges=[(0,1),(1,2),(2,0)]
seq_logs=[]
for t,(i,j) in zip(seq_times,seq_edges):
    ll=loglam0+g*t
    seq_logs.append(float(ll[i]-ll[j]))
seq_H=float(sum(seq_logs))
# At any common epoch the exact physical ratios close.
common=[]
for t in (-1.0,0.0,1.0):
    ll=loglam0+g*t
    common.append(float((ll[0]-ll[1])+(ll[1]-ll[2])+(ll[2]-ll[0])))
add("T586",
    "sequential edge acquisition under stream-specific drift can create false persistent holonomy",
    abs(seq_H)>0.05 and max(abs(x) for x in common)<1e-12,
    f"sequential logH={seq_H:.4f}, while same-epoch control holonomies={common}.")

# T587 — symmetric interleaving cancels all first-order/log-linear drift exactly.
# Each edge is measured at t=-tau and +tau and the two log-ratios are averaged.
tau=1.0
sym=[]
for i,j in seq_edges:
    vals=[]
    for t in (-tau,+tau):
        ll=loglam0+g*t
        vals.append(float(ll[i]-ll[j]))
    sym.append(sum(vals)/2.0)
sym_H=float(sum(sym))
add("T587",
    "symmetric interleaving of every edge at matched early/late epochs cancels log-linear drift",
    abs(sym_H)<1e-12,
    f"symmetrized edge logs={sym}, cycle logH={sym_H:.3e}.")

# T588 — scope verdict. Pulse fan-out after a physical detector proves counter/electronics descent only;
# full sensor/bearer descent requires detector replacement or an equivalent upstream intervention.
all_previous=all(t["pass"] for t in tests)
scope_ok=True
add("T588",
    "minimal three-stream bench candidate passes architecture gates but does not yet close the fundamental Nature-Candidate Gate",
    all_previous and scope_ok,
    "BENCH CANDIDATE PASS: edge-primitive count termination, refinement, two-bank rank and drift firewall. OPEN: sensor-level Instrument Descent and a HOME-specific novel residual beyond standard counting theory.")

result={
    "summary":{"passed":sum(t["pass"] for t in tests),"total":len(tests),"failed":sum(not t["pass"] for t in tests)},
    "status":{
        "internal":"PASS" if all(t["pass"] for t in tests) else "REVIEW",
        "physical_bench_candidate":"PASS" if all(t["pass"] for t in tests) else "REVIEW",
        "nature_candidate":"OPEN",
        "scope":"Concrete three-stream count-terminated bench architecture. Two post-detector counter banks establish electronics/counter descent only; detector/sensor descent and HOME-specific novel prediction remain open."
    },
    "tests":tests
}
print(json.dumps(result,indent=2))
