#!/usr/bin/env python3
"""T589-T598 Standard-Theory Subtraction audit.

This script does not perform a literature search. It reproduces the frozen
classification ledger established by the cited literature audit and checks
its internal consistency. External source verification is recorded in the
companion Markdown report.
"""
import json

TESTS = [{'id': 'T589', 'name': 'Cycle consistency / node-potential reconstruction', 'classification': 'STANDARD INFRASTRUCTURE', 'pass': True, 'detail': 'Classical group synchronization already identifies compatible edge ratios with vertex potentials subject to cycle consistency; not HOME novelty.', 'sources': ['https://link.springer.com/article/10.1007/s40687-026-00627-w', 'https://arxiv.org/abs/1912.11347']}, {'id': 'T590', 'name': 'Connectedness and uniqueness up to one global gauge', 'classification': 'STANDARD INFRASTRUCTURE', 'pass': True, 'detail': 'Connected graph synchronization determines node potentials only up to a global group action/gauge; this is standard.', 'sources': ['https://link.springer.com/article/10.1007/s40687-026-00627-w']}, {'id': 'T591', 'name': 'Holonomy/cohomology obstruction to global synchronization', 'classification': 'STANDARD INFRASTRUCTURE', 'pass': True, 'detail': 'Synchronization obstructions described by flat bundles, holonomy and cohomology predate HOME; retain only as mathematical language.', 'sources': ['https://arxiv.org/abs/1610.09051']}, {'id': 'T592', 'name': 'Residual dimension m-rank([B N])', 'classification': 'STANDARD LINEAR-MODEL CONSEQUENCE', 'pass': True, 'detail': 'The RCC design-identifiability count is rank-nullity / residual degrees of freedom for a linear model; useful specialization, not standalone novelty.', 'sources': ['https://www.itl.nist.gov/div898/strd/lls/data/LINKS/c-NoInt2.shtml', 'https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.OLS.df_resid.html']}, {'id': 'T593', 'name': 'Gradient apparatus shifts are cycle-invisible', 'classification': 'STANDARD HODGE/GRAPH CONSEQUENCE', 'pass': True, 'detail': 'A gradient edge flow is a node-potential difference and has zero circulation on cycles; apparatus-gradient blindness is a physical application of standard Hodge structure.', 'sources': ['https://www.stat.uchicago.edu/~lekheng/work/hodge-graph.pdf', 'https://link.springer.com/article/10.1007/s10915-023-02314-2']}, {'id': 'T594', 'name': 'm-th-event stopping and count-refinement statistics', 'classification': 'STANDARD POINT-PROCESS INFRASTRUCTURE', 'pass': True, 'detail': 'For a Poisson process the kth arrival time is Erlang/Gamma and event-count stopping is classical renewal/point-process theory; not HOME novelty.', 'sources': ['https://www.cambridge.org/core/journals/journal-of-applied-probability/article/distribution-of-the-minimum-observation-until-a-stopping-time-with-an-application-to-the-minimal-spacing-in-a-renewal-process/B78CC0EAA8D092C053A9E384B10556A9', 'https://www.itl.nist.gov/div898/handbook/eda/section3/eda366b.htm']}, {'id': 'T595', 'name': 'Symmetric interleaving cancels linear drift', 'classification': 'STANDARD METROLOGY', 'pass': True, 'detail': 'ABBA/ABA measurement cycles are established drift-elimination designs; the HOME bench candidate may use them but cannot claim the cancellation principle as new.', 'sources': ['https://www.oiml.org/en/files/pdf_r/r111-1-e04.pdf', 'https://www.nist.gov/sites/default/files/documents/calibrations/mono180.pdf']}, {'id': 'T596', 'name': 'Comparator swaps and changed-condition reproducibility', 'classification': 'STANDARD METROLOGY', 'pass': True, 'detail': "Repeatability/reproducibility under changed instruments and conditions is standard metrological practice; HOME's Instrument-Descent Gate is a stricter role assignment, not a new general concept of replication.", 'sources': ['https://www.nist.gov/pml/nist-technical-note-1297/nist-tn-1297-appendix-d1-terminology', 'https://www.nist.gov/publications/nistsematech-engineering-statistics-handbook-chapter-2-measurement-process']}, {'id': 'T597', 'name': 'What survives as HOME-specific after subtraction', 'classification': 'HOME-SPECIFIC PROTOCOL COMPOSITION', 'pass': True, 'detail': 'The distinctive residue is the conjunction of: edge observables before node clocks; no scalar time in the defining edge rule; boundary-refinement gate; nuisance-rank precheck; same-edge Instrument Descent; frozen calibration/holdout split; and explicit refusal to equate downstream synchronization with origin of time. This is presently a protocol/architecture contribution, not a new physical law.', 'sources': []}, {'id': 'T598', 'name': 'Novel-prediction gate after standard-theory subtraction', 'classification': 'NO-GO / GATE REMAINS OPEN', 'pass': True, 'detail': 'After subtracting standard synchronization, Hodge/cohomology, linear-model, point-process and metrological machinery, the current bench candidate leaves no HOME-specific quantitative observable law. Therefore Novel Experimental Prediction remains OPEN; no new postulate is added to force closure.', 'sources': []}]

def main():
    assert len(TESTS) == 10
    assert [t["id"] for t in TESTS] == [f"T{i}" for i in range(589,599)]
    assert all(t["pass"] for t in TESTS)
    physical_predictions = [t for t in TESTS if t["classification"] == "HOME-SPECIFIC PHYSICAL PREDICTION"]
    assert len(physical_predictions) == 0
    result = {
        "summary": {
            "passed": sum(t["pass"] for t in TESTS),
            "total": len(TESTS),
            "failed": sum(not t["pass"] for t in TESTS)
        },
        "verdict": {
            "standard_infrastructure_count": sum(t["classification"].startswith("STANDARD") for t in TESTS),
            "home_specific_protocol_count": sum(t["classification"].startswith("HOME-SPECIFIC") for t in TESTS),
            "novel_physical_prediction_count": len(physical_predictions),
            "novel_prediction_gate": "OPEN",
            "action": "Demote standard mathematics/metrology from novelty claims; retain HOME-specific contribution as protocol architecture; continue Novel-Prediction search."
        },
        "tests": TESTS
    }
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
