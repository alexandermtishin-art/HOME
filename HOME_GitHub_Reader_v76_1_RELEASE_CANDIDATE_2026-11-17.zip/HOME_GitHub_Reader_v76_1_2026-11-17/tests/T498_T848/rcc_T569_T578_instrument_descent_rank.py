#!/usr/bin/env python3
"""HOME RCC T569-T578: Instrument-Descent rank and minimal replication controls."""
from __future__ import annotations
import json
import sympy as sp

tests=[]
def add(i,n,ok,d): tests.append({'id':i,'name':n,'pass':bool(ok),'detail':d})

# Oriented triangle edges AB, BC, CA.
B=sp.Matrix([[1,-1,0],[0,1,-1],[-1,0,1]])
assert B.rank()==2

def rep_B(R):
    rows=[]
    for r in range(R): rows += [list(B.row(e)) for e in range(3)]
    return sp.Matrix(rows)

def app_main(R):
    # One free apparatus-realization offset xi_r, common to its three edges.
    M=sp.zeros(3*R,R)
    for r in range(R):
        for e in range(3): M[3*r+e,r]=1
    return M

def edge_app_free(R):
    # Arbitrary edge x apparatus bias: one free nuisance per raw observation.
    return sp.eye(3*R)

# T569 single triangle, one free apparatus-main mode consumes sole cycle test.
D1=rep_B(1).row_join(app_main(1)); d1=3-D1.rank()
add('T569','one triangle with one free comparator-main mode has no surviving exact RCC residual',d1==0,f'd_test=3-rank([B A])={d1}.')

# T570 one distinct unconstrained module per edge is even worse: I3 nuisance exhausts data.
I3=sp.eye(3); d_rot=3-B.row_join(I3).rank()
add('T570','one unconstrained comparator module per edge makes a triangle unfalsifiable',d_rot==0,f'd_test={d_rot}; rotating one biased module per edge cannot establish descent.')

# T571 two fully replicated apparatus triangles, before freeing apparatus modes: raw residual dim 4.
B2=rep_B(2); draw=6-B2.rank()
add('T571','two complete apparatus realizations give four raw null-space contrasts before apparatus quotient',draw==4,f'6 observations - rank(B_rep)={draw}.')

# T572 intuitive 5 contrasts have rank 4: cycle1, cycle2, and three same-edge differences.
# coefficient vectors on [AB1,BC1,CA1, AB2,BC2,CA2]
C1=sp.Matrix([[1,1,1,0,0,0]])
C2=sp.Matrix([[0,0,0,1,1,1]])
Dab=sp.Matrix([[1,0,0,-1,0,0]])
Dbc=sp.Matrix([[0,1,0,0,-1,0]])
Dca=sp.Matrix([[0,0,1,0,0,-1]])
K=sp.Matrix.vstack(C1,C2,Dab,Dbc,Dca)
add('T572','two cycles plus three same-edge descent contrasts contain one exact dependency',K.rank()==4,'five intuitive contrasts have rank 4; C1-C2 = Dab+Dbc+Dca.')

# T573 free apparatus-main offsets for the two realizations leave two residual dimensions.
A2=app_main(2); d2=6-B2.row_join(A2).rank()
add('T573','two full triangles retain positive falsifiability after quotienting two apparatus-main offsets',d2==2,f'd_test=6-rank([B_rep A_main])={d2}.')

# T574 arbitrary edge x apparatus nuisance destroys falsifiability completely.
dfree=6-B2.row_join(edge_app_free(2)).rank()
add('T574','arbitrary edge-by-apparatus nuisance modes destroy all RCC falsifiability',dfree==0,f'd_test={dfree}; Instrument Descent cannot be replaced by freely fitting every comparator-edge cell.')

# T575 same-edge swaps detect edge-specific apparatus difference directions directly.
# The three paired differences are independent.
S=sp.Matrix.vstack(Dab,Dbc,Dca)
add('T575','same-edge apparatus swaps supply three independent descent contrasts',S.rank()==3 and (S*B2)==sp.zeros(3,3),f'rank(same-edge contrasts)={S.rank()}, and they annihilate bearer node potentials.')

# T576 three full apparatus realizations: after free apparatus main effects, 4 residuals.
B3=rep_B(3); A3=app_main(3); d3=9-B3.row_join(A3).rank()
add('T576','third full apparatus realization increases post-nuisance residual dimension predictably',d3==4,f'd_test=9-rank([B_rep A_main])={d3}.')

# T577 general connected-graph formula stress on complete graphs K3..K6 and R=1..4.
def incidence_complete(n):
    edges=[(i,j) for i in range(n) for j in range(i+1,n)]
    M=sp.zeros(len(edges),n)
    for r,(i,j) in enumerate(edges): M[r,i]=1; M[r,j]=-1
    return M
ok=True; cases=0; worst=[]
for n in range(3,7):
    G=incidence_complete(n); E=G.rows
    for R in range(1,5):
        Grep=sp.Matrix.vstack(*([G]*R))
        A=sp.zeros(E*R,R)
        for rr in range(R):
            for e in range(E): A[rr*E+e,rr]=1
        got=E*R-Grep.row_join(A).rank()
        pred=E*R-((n-1)+R)
        ok &= got==pred
        worst.append((n,R,got,pred)); cases+=1
add('T577','general apparatus-main rank formula holds on connected complete-graph controls',ok,f'verified {cases} cases: d_test=E R-(V-1)-R.')

# T578 minimal triangle replication rule under apparatus-main model, plus scope firewall.
# R=1 -> 0, R=2 -> 2. Edge-specific free interactions remain untestable (T574).
minimal=(d1==0 and d2>0)
add('T578','minimal Instrument-Descent replication theorem for a triangle requires at least two full comparator realizations under the apparatus-main model',minimal,'R=1 gives d_test=0; R=2 gives d_test=2. This sufficiency fails if arbitrary edge×apparatus interactions are left free.')

res={'summary':{'passed':sum(t['pass'] for t in tests),'total':len(tests),'failed':sum(not t['pass'] for t in tests)},'status':{'internal':'PASS' if all(t['pass'] for t in tests) else 'REVIEW','nature_candidate':'OPEN','scope':'rank theorem assumes free apparatus main effects common across the edges measured by one realization; arbitrary edge×apparatus interactions require additional physical constraints/replication.'},'tests':tests}
print(json.dumps(res,indent=2))
