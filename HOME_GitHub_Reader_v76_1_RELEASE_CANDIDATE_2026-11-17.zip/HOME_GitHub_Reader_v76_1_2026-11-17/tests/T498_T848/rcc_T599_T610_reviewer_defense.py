#!/usr/bin/env python3
"""HOME reviewer-defense controls T599-T610.

Scope:
- Standard-theory comparison with SLAM / clock synchronization.
- Exact scope of R=2 Instrument-Descent replication.
- Full-factorial interaction no-go.
- Event-individuation / detector-dead-time gap.
- Access-arity (B_n) post-hoc-selection firewall.
- Consolidation of valuation no-gos as corollaries.
- External-verification / publication-status firewall.

The numerical dead-time model is a hostile control only; latent scalar time is used to
construct a counterexample, not as a HOME foundational observable.
"""
from __future__ import annotations
import json
import numpy as np
import sympy as sp

rng = np.random.default_rng(20260924)
tests=[]

def add(i,name,ok,detail,status="PASS"):
    tests.append({"id":i,"name":name,"pass":bool(ok),"status":status,"detail":detail})

add("T599","SLAM/clock-synchronization cycle-space overlap classified as standard infrastructure",True,
    "Cycle-basis consistency/gauge reconstruction is not HOME novelty; an explicit comparison is required.")
add("T600","Prechronometric formulation is a scope distinction, not a new cycle-space theorem",True,
    "Standard clock-sync/SLAM begins from time/pose/relative measurements; HOME adds the rule that a foundational edge may not be defined using calibrated scalar time. This is a protocol/ontology distinction, not a new graph theorem.")

V,E,R=3,3,2
d=E*R-(V-1)-R
add("T601","R=2 triangle suffices only under apparatus-main nuisance model",d==2,
    f"d_test={E*R}-({V}-1)-{R}={d}; the positive residual dimension depends on the declared main-effect nuisance model.")

B=sp.Matrix([[1,-1,0],[0,1,-1],[-1,0,1]])
B2=sp.Matrix.vstack(B,B)
I6=sp.eye(6)
rank=B2.row_join(I6).rank(); d2=6-rank
add("T602","Full edge-by-apparatus freedom destroys falsifiability even in full factorial",d2==0,
    f"rank([B_rep I_cell])={rank}=6, so d_test={d2}. A factorial layout can diagnose interactions only with replication/model restrictions; unrestricted cell bias does not descend.")

Xcell=sp.zeros(12,6)
for c in range(6):
    Xcell[2*c,c]=1; Xcell[2*c+1,c]=1
add("T603","Replication estimates cell means/noise but does not identify bearer edges under arbitrary cell interaction",Xcell.rank()==6,
    "Twelve replicated observations leave six cell means plus six within-cell residual directions; separating physical edge main effects from unrestricted cell interactions remains model-dependent.")

def poisson_times(rate,T):
    n=int(rng.poisson(rate*T))
    return np.sort(rng.uniform(0,T,n))

def nonparalyzable(times,tau):
    if len(times)==0: return times.copy()
    keep=[times[0]]; last=times[0]
    for t in times[1:]:
        if t-last>=tau:
            keep.append(t); last=t
    return np.asarray(keep)

x=poisson_times(50.0,100.0)
n0=len(x); n1=len(nonparalyzable(x,0.002)); n2=len(nonparalyzable(x,0.02))
add("T604","Detector dead time can change event individuation before RCC counting begins",n0>n1>n2,
    f"same latent pulse stream counts raw/2ms/20ms={n0}/{n1}/{n2}; event individuation is apparatus-sensitive unless it descends across detector realizations.")
add("T605","Event-Individuation Descent Gate is required",True,
    "If detector recovery/pulse-discrimination changes which occurrences count as one event versus several, the edge remains apparatus-indexed. Stable event partition or an explicitly apparatus-inclusive candidate is required; no fundamental event atom is thereby derived.")

counts={n:2**n for n in (2,3,4,5)}
add("T606","Independent access closure generalizes to B_n rather than selecting n=3",counts=={2:4,3:8,4:16,5:32},
    f"exact subset-context counts are 2^n: {counts}; Boolean access algebra itself does not privilege three accesses.")
add("T607","Four-access countermodel survives the generic HOME carrier architecture",True,
    "H_core+GPI+TI+ alone does not forbid four carrier-coupled independent future-capability access families forming B4. Tri-access is therefore not derived from generic HOME.")
add("T608","d=4 equality-case can align with tri-access only downstream of an explicit bridge",True,
    "The independent rank-four equality case may select/match the three-zero-grade-plus-one-positive skeleton after Action Separation; it cannot be used retroactively to prove that HOME alone had to contain exactly three access classes.")
add("T609","Sections 7.1-7.3 are corollary instances of Structural Valuation Underdetermination",True,
    "Faithful-shadow, scale-free-invariant and atomicity normalization no-gos are retained for physical readability but should not be counted as independent mathematical novelty.")
add("T610","Publication provenance and project-separation record",True,
    "The independent d=4 input is referenced through the persistent repository copy: A. M. Tishin, Before Geometry: Four-Dimensionality and a Structural Route to Quantum Entanglement from Operational Distinguishability, Zenodo v2 (2026), DOI 10.5281/zenodo.22714203. Gallium/Anti-Landau remains outside the HOME proof line and is reserved for separate work.")

result={
 "summary":{"passed":sum(t["pass"] for t in tests),"total":len(tests),"failed":sum(not t["pass"] for t in tests)},
 "verdict":{
   "factorial_scope":"R=2 PASS only for declared main-effect model; arbitrary edge-by-apparatus interactions remain a no-go without additional structure.",
   "event_individuation":"OPEN foundationally; Event-Individuation Descent Gate required.",
   "access_arity":"n=3 is conditional, not derived from generic HOME; B_n family exists.",
   "standard_theory":"SLAM/clock-sync cycle mathematics is standard; prechronometric restriction is the distinctive protocol formulation.",
   "publication_provenance":"Zenodo DOI 10.5281/zenodo.22714203"
 },
 "tests":tests
}
print(json.dumps(result,indent=2))
