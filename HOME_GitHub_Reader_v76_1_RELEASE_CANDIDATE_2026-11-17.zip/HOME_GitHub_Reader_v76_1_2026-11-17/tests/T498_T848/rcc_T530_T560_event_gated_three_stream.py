#!/usr/bin/env python3
"""HOME RCC controls T530-T560.

Minimal event-gated three-stream design with:
  * one nontrivial RCC cycle (d_test > 0),
  * boundary/event-count refinement,
  * same-edge Instrument-Descent replication,
  * raw holdout innovation / tautology controls,
  * monotone-reparameterization audit,
  * null calibration and power separation.

This is an internal architecture/identifiability stress test. It is not evidence
that Nature realizes the candidate.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np

rng = np.random.default_rng(20260924)
tests=[]

def add(i,name,ok,detail):
    tests.append({'id':i,'name':name,'pass':bool(ok),'detail':detail})

def nrank(M,tol=1e-10):
    M=np.asarray(M,dtype=float)
    return 0 if M.size==0 else int(np.linalg.matrix_rank(M,tol))

# Oriented triangle: AB, BC, CA.  b = B z gives b_AB+b_BC+b_CA=0.
B=np.array([[1.,-1.,0.],[0.,1.,-1.],[-1.,0.,1.]])
c=np.array([1.,1.,1.])

# -----------------------------------------------------------------------------
# T530-T538: exact design and Instrument-Descent geometry.
# -----------------------------------------------------------------------------
d_test=3-nrank(B)
add('T530','Minimal three-stream triangle has a nonzero RCC test dimension',
    d_test==1,f'm=3, rank(B)={nrank(B)}, d_test={d_test}.')

N_closure=np.array([[1.],[0.],[0.]])
add('T531','One free closure-active nuisance destroys minimal-triangle falsifiability',
    3-nrank(np.c_[B,N_closure])==0,
    f'rank([B N])={nrank(np.c_[B,N_closure])}, d_test={3-nrank(np.c_[B,N_closure])}.')

N_grad=(B@np.array([[0.],[1.],[-2.]])).reshape(3,1)
add('T532','A gradient-like nuisance does not consume the triangle cycle test',
    3-nrank(np.c_[B,N_grad])==1,
    f'rank(B)={nrank(B)}, rank([B N_grad])={nrank(np.c_[B,N_grad])}.')

# Two complete apparatus arms: A and A'.
c0=np.array([1.,1.,1.,0.,0.,0.])
c1=np.array([0.,0.,0.,1.,1.,1.])
D=[]
for e in range(3):
    v=np.zeros(6); v[e]=-1; v[e+3]=1; D.append(v)
D=np.array(D)
all_contrasts=np.vstack([c0,c1,D])
add('T533','Two arm cycles plus all same-edge descent contrasts contain one exact redundancy',
    nrank(all_contrasts)==4,
    f'5 written contrasts have rank {nrank(all_contrasts)} because sum(descent)=cycle_Aprime-cycle_A.')

primary_plus_descent=np.vstack([c0,D])
add('T534','One primary RCC cycle plus three same-edge descent contrasts are jointly independent',
    nrank(primary_plus_descent)==4,
    f'contrast rank={nrank(primary_plus_descent)} on six replicated edge observations.')

identity=np.allclose(c1, c0 + D.sum(axis=0))
add('T535','The second apparatus cycle is derived once the primary cycle and all descent contrasts are known',
    identity,'cycle_Aprime = cycle_A + sum_e(Aprime_e-A_e) exactly.')

q=np.array([0.07,-0.03,0.02])
grad_shift=B@q
add('T536','A nonzero apparatus gradient can be invisible to RCC closure but visible to same-edge descent',
    abs(c@grad_shift)<1e-12 and np.linalg.norm(grad_shift)>1e-6,
    f'cycle shift={c@grad_shift:.3e}, same-edge shift norm={np.linalg.norm(grad_shift):.3e}.')

zero_sum=np.array([0.02,-0.03,0.01])
add('T537','Zero-sum edge-module bias can fake perfect closure while failing Instrument Descent',
    abs(zero_sum.sum())<1e-12 and np.max(np.abs(zero_sum))>0,
    f'cycle bias sum={zero_sum.sum():.3e}, max same-edge bias={np.max(np.abs(zero_sum)):.3e}.')

closure_active=np.array([0.02,-0.03,0.02])
add('T538','A closure-active apparatus bias is visible to both RCC and Instrument Descent',
    abs(closure_active.sum())>5e-3 and np.max(np.abs(closure_active))>1e-2,
    f'cycle bias={closure_active.sum():.3e}, max same-edge bias={np.max(np.abs(closure_active)):.3e}.')

# -----------------------------------------------------------------------------
# Event-gated stochastic three-stream model.
# Latent time is used only by the simulation generator. The measurement rule is:
# terminate each pairwise bracket after m monitor events and report count ratio.
# -----------------------------------------------------------------------------
rates=np.array([1.0,1.7,0.75])
ref_rate=1.2
edges=[(0,1),(1,2),(2,0)]

def edge_ratio_samples(i,j,m,ntr=3000,eff=None,context_factor=1.0):
    if eff is None: eff=np.ones(3)
    T=rng.gamma(shape=m,scale=1/ref_rate,size=ntr)
    li=rates[i]*eff[i]
    lj=rates[j]*eff[j]
    # context_factor multiplies the numerator process only in this edge context.
    ni=rng.poisson(li*context_factor*T)
    nj=rng.poisson(lj*T)
    mask=(ni>0)&(nj>0)
    rr=ni[mask]/nj[mask]
    return rr

def cycle_log_samples(m,ntr=3000,eff=None,edge_factors=None):
    if eff is None: eff=np.ones(3)
    if edge_factors is None: edge_factors=np.ones(3)
    out=np.empty(ntr)
    for k in range(ntr):
        s=0.0
        for e,(i,j) in enumerate(edges):
            T=float(rng.gamma(shape=m,scale=1/ref_rate))
            ni=int(rng.poisson(rates[i]*eff[i]*edge_factors[e]*T))
            nj=int(rng.poisson(rates[j]*eff[j]*T))
            if ni<=0 or nj<=0:
                s=np.nan; break
            s += math.log(ni/nj)
        out[k]=s
    return out[np.isfinite(out)]

# T539 edge refinement.
errs=[]
for m in (100,1000,10000):
    per=[]
    for i,j in edges:
        rr=edge_ratio_samples(i,j,m,ntr=2500)
        target=rates[i]/rates[j]
        per.append(float(np.median(np.abs(rr/target-1))))
    errs.append(float(np.median(per)))
add('T539','All three event-gated edges refine toward their stationary ratios',
    errs[2]<errs[1]<errs[0],f'median-of-edge relative errors={errs}.')

# T540 cycle refinement.
rms=[]
for m in (100,1000,10000):
    h=cycle_log_samples(m,ntr=2200)
    rms.append(float(np.sqrt(np.mean(h*h))))
add('T540','Three-edge event-gated holonomy contracts under refinement',
    rms[2]<rms[1]<rms[0],f'RMS log holonomy={rms}.')

# T541 scaling exponent around -1/2 for stochastic count noise.
ms=np.array([200.,800.,3200.,12800.])
rrms=[]
for m in ms.astype(int):
    h=cycle_log_samples(m,ntr=1800)
    rrms.append(float(np.sqrt(np.mean(h*h))))
slope=float(np.polyfit(np.log(ms),np.log(rrms),1)[0])
add('T541','Stochastic event-count holonomy follows the expected inverse-square-root refinement scale',
    -0.68<slope<-0.32,f'log-log slope={slope:.3f}, RMS={rrms}.')

# Deterministic periodic boundary/phase model.
period=np.array([1.0,math.sqrt(2),math.pi/2])
phase=np.array([0.17,0.31,0.07])
def count_periodic(p,ph,a,b):
    lo=math.floor((a-ph)/p)+1; hi=math.floor((b-ph)/p)
    return max(0,hi-lo+1)
def periodic_edge(i,j,ref,m,start):
    a=phase[ref]+start*period[ref]
    b=phase[ref]+(start+m)*period[ref]
    return count_periodic(period[i],phase[i],a,b)/count_periodic(period[j],phase[j],a,b)
dsmall=abs(periodic_edge(0,1,2,50,1)-periodic_edge(0,1,2,50,2))
dlarge=abs(periodic_edge(0,1,2,5000,1)-periodic_edge(0,1,2,5000,2))
add('T542','Bracket-phase sensitivity decays in the concrete three-stream periodic control',
    dlarge<dsmall/10,f'phase difference 50->{dsmall:.3e}, 5000->{dlarge:.3e}.')

# T543 genuine context anomaly persists.
h0=cycle_log_samples(2000,ntr=2500,edge_factors=np.array([1.,1.03,1.]))
h1=cycle_log_samples(20000,ntr=2500,edge_factors=np.array([1.,1.03,1.]))
med0=float(np.median(h0)); med1=float(np.median(h1)); target=math.log(1.03)
add('T543','A genuine edge-context anomaly survives event-count refinement',
    abs(med1-target)<0.006 and abs(med1)>0.02,
    f'median log holonomy m=2000:{med0:.4f}, m=20000:{med1:.4f}, target={target:.4f}.')

# Apparatus gradient: node efficiencies. Closure remains null but same-edge values move.
effB=np.array([0.94,1.02,1.07])
shift=np.array([math.log(effB[i]/effB[j]) for i,j in edges])
hB=cycle_log_samples(12000,ntr=2200,eff=effB)
add('T544','Persistent node-efficiency apparatus bias is refinement-stable yet RCC-cycle blind',
    abs(shift.sum())<1e-12 and abs(float(np.median(hB)))<0.01 and np.max(np.abs(shift))>0.05,
    f'asymptotic same-edge shifts={shift.tolist()}, sum={shift.sum():.3e}, median cycle={np.median(hB):.3e}.')

# Non-gradient edge-specific apparatus factor produces closure.
edge_bias=np.array([1.00,1.02,0.99])
hE=cycle_log_samples(15000,ntr=2200,edge_factors=edge_bias)
expected=float(np.log(edge_bias).sum())
add('T545','A non-gradient edge-specific apparatus distortion survives refinement and is RCC-visible',
    abs(float(np.median(hE))-expected)<0.006 and abs(expected)>0.005,
    f'median cycle={np.median(hE):.4f}, expected={expected:.4f}.')

# Nonparalyzable dead-time effective-rate model: lambda_eff=lambda/(1+lambda*tau).
def dead_eff(tau):
    le=rates/(1+rates*tau)
    return le/rates
ed=dead_eff(0.08)
dead_shift=np.array([math.log(ed[i]/ed[j]) for i,j in edges])
add('T546','Rate-dependent detector dead time can persist under refinement while remaining cycle-neutral',
    abs(dead_shift.sum())<1e-12 and np.max(np.abs(dead_shift))>0.03,
    f'effective efficiencies={ed.tolist()}, same-edge shifts={dead_shift.tolist()}.')

# A common multiplicative efficiency on both channels of an edge cancels in that ratio.
common=0.73
rbase=rates[0]/rates[1]
rcommon=(common*rates[0])/(common*rates[1])
add('T547','A truly common pairwise detection efficiency is benign for a count ratio',
    abs(rbase-rcommon)<1e-15,f'base={rbase:.12g}, with common efficiency={rcommon:.12g}.')

# -----------------------------------------------------------------------------
# T548-T550: three-way gate separation: boundary artifact vs apparatus artifact
# vs genuine context anomaly.
# -----------------------------------------------------------------------------
finite_boundary_decay = dlarge < dsmall/10
instrument_persistent = np.max(np.abs(shift))>0.05 and abs(shift.sum())<1e-12
genuine_persistent = abs(med1)>0.02
add('T548','Finite-boundary artifact is rejected as a fundamental RCC anomaly by the refinement gate',
    finite_boundary_decay,f'boundary-phase discrepancy contracts {dsmall:.3e}->{dlarge:.3e}.')
add('T549','Apparatus-gradient artifact is rejected by Instrument Descent even though refinement and closure can look good',
    instrument_persistent,
    f'nonzero stable same-edge apparatus shift with exactly zero asymptotic cycle sum.')
add('T550','A context anomaly that is apparatus-common and refinement-stable survives both pre-RCC gates',
    genuine_persistent and abs(target)>0.02,
    f'common edge factor 1.03 gives stable log-cycle target {target:.4f}; it is not removed by refinement or apparatus swapping.')

# -----------------------------------------------------------------------------
# T551-T555: tautology, holdout innovation, and prechronometric rule audit.
# -----------------------------------------------------------------------------
N=np.array([53.,79.,31.])
shared_product=(N[0]/N[1])*(N[1]/N[2])*(N[2]/N[0])
add('T551','Ratios derived from one shared node-count snapshot close tautologically',
    abs(shared_product-1)<1e-15,f'shared-count cycle product={shared_product:.17g}.')

pair_counts=[(53.,79.),(80.,31.),(30.,52.)]
ind_product=np.prod([a/b for a,b in pair_counts])
add('T552','Independently bracketed pairwise counts do not impose algebraic cycle closure',
    abs(ind_product-1)>1e-3,f'independent-pair cycle product={ind_product:.8f}.')

# Raw rows: shared node logs -> third edge derived; six private pair-count logs -> all 3 independent.
J_shared=B.copy()
J_private=np.array([
    [1.,-1.,0.,0.,0.,0.],
    [0.,0.,1.,-1.,0.,0.],
    [0.,0.,0.,0.,1.,-1.]
])
add('T553','Independent pairwise acquisition gives positive raw holdout innovation whereas shared-node ratios do not',
    nrank(J_shared[:2])==nrank(J_shared) and nrank(J_private[:2])<nrank(J_private),
    f'shared ranks 2->{nrank(J_shared)}; private ranks 2->{nrank(J_private)}.')

# Order/count extractor invariant under monotone relabeling of latent event parameter.
def make_event_record(m=80):
    # generate enough events until monitor m-th event
    mt=np.cumsum(rng.exponential(1/ref_rate,size=m))
    stop=mt[-1]
    records=[]
    for lab,lam in [('A',rates[0]),('B',rates[1]),('M',ref_rate)]:
        if lab=='M': ts=mt
        else:
            n=max(4,int(stop*lam*1.8)+20)
            ts=np.cumsum(rng.exponential(1/lam,size=n))
            ts=ts[ts<=stop]
        records.extend((float(t),lab) for t in ts)
    records.sort()
    return records

def count_rule(records,m=60):
    # only event order and labels are consumed
    mon=0; a=b=0
    for _,lab in records:
        if lab=='M':
            mon+=1
            if mon>=m: break
        elif lab=='A': a+=1
        elif lab=='B': b+=1
    return a,b,a/b
rec=make_event_record(100)
r1=count_rule(rec,70)
rec2=[(t+0.15*t*t,lab) for t,lab in rec]
rec2.sort()
r2=count_rule(rec2,70)
add('T554','Event-order/count edge extraction is invariant under monotone history reparameterization',
    r1==r2,f'counts/ratio before={r1}, after monotone relabel={r2}.')

t1,t2,Delta=1.0,1.4,0.5
before=abs(t2-t1)<Delta
g=lambda x:x*x
after=abs(g(t2)-g(t1))<Delta
add('T555','A fixed numerical time-window predicate fails the same reparameterization audit',
    before and not after,f'|dt|={abs(t2-t1):.2f}<0.5 but |d(t^2)|={abs(g(t2)-g(t1)):.2f}>0.5.')

# -----------------------------------------------------------------------------
# T556-T559: null calibration and separated power.
# -----------------------------------------------------------------------------
def approx_cycle_var(m, eff=None):
    if eff is None: eff=np.ones(3)
    # E[1/T] approx ref_rate/(m-1), and Var(log Ni/Nj) approx 1/E[Ni]+1/E[Nj].
    fac=ref_rate/(m-1)
    return fac*sum((1/(rates[i]*eff[i]) + 1/(rates[j]*eff[j])) for i,j in edges)

mnull=5000
h=cycle_log_samples(mnull,ntr=6000)
v=approx_cycle_var(mnull)
z=h/math.sqrt(v)
Q=z*z
zmean=float(np.mean(z)); zvar=float(np.var(z)); q95=float(np.quantile(Q,0.95))
add('T556','Frozen one-cycle noisy statistic is approximately calibrated under the clean null',
    abs(zmean)<0.07 and 0.85<zvar<1.15 and 3.2<q95<4.6,
    f'z mean={zmean:.3f}, var={zvar:.3f}, Q95={q95:.3f} (chi2_1 target 3.84).')

# Power for a 2% persistent context anomaly should increase with refinement.
def cycle_reject_rate(m,factor=1.05,ntr=2800):
    hh=cycle_log_samples(m,ntr=ntr,edge_factors=np.array([1.,factor,1.]))
    vv=approx_cycle_var(m)
    return float(np.mean((hh*hh/vv)>3.841458820694124))
pows=[cycle_reject_rate(m) for m in (500,5000,50000)]
add('T557','Power against a persistent context anomaly increases with event-count refinement',
    pows[2]>pows[1]>pows[0] and pows[2]>0.90,
    f'rejection rates m=500,5000,50000: {pows}.')

# RCC cycle remains blind to a pure apparatus-gradient shift asymptotically.
# Simulate apparatus B with node efficiencies; its null cycle rejection should remain near nominal.
hgrad=cycle_log_samples(mnull,ntr=5000,eff=effB)
vgrad=approx_cycle_var(mnull,eff=effB)
rej_grad=float(np.mean((hgrad*hgrad/vgrad)>3.841458820694124))
add('T558','RCC cycle alone has no power against a pure apparatus-gradient shift',
    0.025<rej_grad<0.08,
    f'cycle rejection under nontrivial gradient apparatus bias={rej_grad:.3f} (nominal 0.05).')

# Instrument-descent test: compare apparatus A vs B on the same edges.
def descent_reject_rate(m,eff2,nexp=2500):
    # Each experiment uses one independent bracket per edge per apparatus.
    # Diagonal delta-method variance is adequate for the internal control.
    crit=7.814727903251179 # chi2_3, 95%
    rejects=0
    for _ in range(nexp):
        dif=[]; vars_=[]
        for i,j in edges:
            T1=float(rng.gamma(shape=m,scale=1/ref_rate)); T2=float(rng.gamma(shape=m,scale=1/ref_rate))
            n1i=max(1,int(rng.poisson(rates[i]*T1))); n1j=max(1,int(rng.poisson(rates[j]*T1)))
            n2i=max(1,int(rng.poisson(rates[i]*eff2[i]*T2))); n2j=max(1,int(rng.poisson(rates[j]*eff2[j]*T2)))
            dif.append(math.log(n2i/n2j)-math.log(n1i/n1j))
            fac=ref_rate/(m-1)
            vars_.append(fac*((1/rates[i]+1/rates[j])+(1/(rates[i]*eff2[i])+1/(rates[j]*eff2[j]))))
        qd=float(np.sum(np.square(dif)/np.asarray(vars_)))
        rejects += qd>crit
    return rejects/nexp

desc_null=descent_reject_rate(5000,np.ones(3),nexp=1800)
desc_bias=descent_reject_rate(5000,effB,nexp=1800)
add('T559','Same-edge Instrument-Descent replication detects the gradient apparatus shift missed by RCC',
    0.02<desc_null<0.09 and desc_bias>0.90,
    f'descent rejection null={desc_null:.3f}, gradient-biased apparatus={desc_bias:.3f}.')

# -----------------------------------------------------------------------------
# T560 integrated architecture verdict.
# The clean architecture must simultaneously possess d_test>0, refinement
# contraction, and an independently calibrated Instrument-Descent control.
# -----------------------------------------------------------------------------
integrated=(d_test>0 and rms[2]<rms[1]<rms[0] and 0.02<desc_null<0.09 and nrank(primary_plus_descent)==4)
add('T560','Minimal event-gated three-stream architecture simultaneously retains RCC falsifiability, refinement stability and independent Instrument Descent',
    integrated,
    f'd_test={d_test}; holonomy RMS {rms[0]:.3g}->{rms[1]:.3g}->{rms[2]:.3g}; descent-null rejection={desc_null:.3f}; joint contrast rank={nrank(primary_plus_descent)}.')

result={
  'series':'HOME RCC T530-T560',
  'scope':'internal computational architecture controls; not a Nature-candidate validation',
  'seed':20260924,
  'summary':{
    'passed':sum(t['pass'] for t in tests),
    'total':len(tests),
    'failed':sum(not t['pass'] for t in tests)
  },
  'tests':tests
}
print(json.dumps(result,indent=2))

out=Path(__file__).with_name('home_rcc_event_gated_three_stream_T530_T560_results.json')
out.write_text(json.dumps(result,indent=2),encoding='utf-8')
