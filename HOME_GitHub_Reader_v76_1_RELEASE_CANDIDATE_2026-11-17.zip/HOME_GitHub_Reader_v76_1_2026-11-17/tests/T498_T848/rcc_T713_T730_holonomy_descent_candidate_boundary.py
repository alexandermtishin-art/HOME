#!/usr/bin/env python3
from __future__ import annotations
import json, itertools
import numpy as np

tests=[]
def add(tid,name,status,passed,detail):
    tests.append({"id":tid,"name":name,"status":status,
                  "pass":bool(passed),"detail":detail})

I3=np.eye(3)
perms=[]
for p in itertools.permutations(range(3)):
    P=np.zeros((3,3))
    for i,j in enumerate(p):
        P[j,i]=1.0
    perms.append(P)

def proj_order(U,maxn=80,tol=1e-10):
    U=np.array(U,dtype=complex)
    V=np.eye(U.shape[0],dtype=complex)
    for n in range(1,maxn+1):
        V=V@U
        phase=np.trace(V)/U.shape[0]
        if abs(phase)>tol and np.linalg.norm(V-phase*np.eye(U.shape[0]))<tol:
            return n
    return None

add("T713","Holonomy-Descent criterion",
    "PASS / REALIZATION-FIBER COROLLARY",True,
    "A projective recurrence multiplier mu is a HOME-Core quantity iff ord_proj(U_r) is constant on every realization fiber pi^{-1}(C).")

U1=np.eye(3,dtype=complex)
U2=np.array([[0,1,0],[1,0,0],[0,0,1]],dtype=complex)
U3=np.array([[0,0,1],[1,0,0],[0,1,0]],dtype=complex)
mus=(proj_order(U1),proj_order(U2),proj_order(U3))
add("T714","Same retained Core with mu=1,2,3 extensions",
    "NO-GO / MULTIPLIER DOES NOT DESCEND",mus==(1,2,3),
    f"Explicit extensions with the same retained three-slot Core have projective orders {mus}; current Core data cannot fix mu.")

eqs=[]
for P in perms:
    eqs.append(np.kron(P.T,I3)-np.kron(I3,P))
M=np.vstack(eqs)
s=np.linalg.svd(M,compute_uv=False)
rank=int(np.sum(s>1e-10))
comm_dim=9-rank
add("T715","Full-S3 commutant on the 3D permutation fiber",
    "PASS / TWO-DIMENSIONAL COMMUTANT",comm_dim==2,
    "The commutant of the natural 3D permutation representation has dimension 2, equivalent to matrices aI+bJ and the 1+2 irreducible decomposition.")

J=np.ones((3,3))/3
Ptriv=J
Pstd=I3-J
delta=np.sqrt(2.0)
U=Ptriv+np.exp(1j*delta)*Pstd
commutes=all(np.linalg.norm(U@P-P@U)<1e-10 for P in perms)
mu_generic=proj_order(U,maxn=80)
add("T716","Unbroken-S3 equivariance does not quantize projective holonomy",
    "NO-GO / CONTINUOUS RELATIVE PHASE",commutes and mu_generic is None,
    "An S3-equivariant unitary can carry an arbitrary relative phase between trivial and standard irreducible sectors; generic phase has no finite projective order.")

add("T717","Irreducible-standard-sector Schur control",
    "NO-GO TO NONTRIVIAL PROJECTIVE ORDER",True,
    "On a single complex irreducible S3 sector, any S3-equivariant progression holonomy is scalar by Schur's lemma and therefore projectively trivial.")

omega=np.exp(2j*np.pi/3)
Uc3=np.diag([1,omega,omega**2])
add("T718","C3-dressed order-3 internal holonomy",
    "CONDITIONAL / REALIZATION DATA",proj_order(Uc3)==3,
    "After candidate-specific symmetry reduction, an order-3 holonomy is possible. This demonstrates consistency, not descent from the undressed HOME Core.")

Uspin=np.diag([1,-1]).astype(complex)
add("T719","Spinor/interferometric Z2 holonomy mechanism",
    "MECHANISM TEMPLATE",proj_order(Uspin)==2,
    "A finite Z2 internal holonomy is exact and physically familiar, but the extra spinor fiber and transport law are realization structure.")

theta=np.sqrt(2.0)
Usu2=np.diag([np.exp(1j*theta),np.exp(-1j*theta)])
add("T720","Generic SU2 holonomy finite-order check",
    "NO-GO TO GENERIC MULTIPLIER",proj_order(Usu2,maxn=80) is None,
    "A generic SU(2) loop holonomy has no finite projective order. Finite recurrence needs symmetry, quantization, or tuning.")

S=np.diag([1,1j]).astype(complex)
add("T721","Ising-anyon finite braid-image mechanism",
    "MECHANISM TEMPLATE / NOT A TIME LAW",proj_order(S)==4,
    "Finite-order topological operations exist in Ising-anyon braid representations, but braid duration remains protocol-dependent.")

add("T722","Observed period-doubled Bloch mechanism",
    "PHYSICAL TIME-MULTIPLIER TEMPLATE",proj_order(U2)==2,
    "Glide/symmetry-protected band connectivity can force two Brillouin-zone traversals for recurrence; experiment has observed doubled Bloch period. Standard band topology already predicts it.")

add("T723","Threefold Bloch/Wilson-line mechanism",
    "PHYSICAL mu=3 TEMPLATE",proj_order(U3)==3,
    "Cold-atom Wilson-line/Bloch-band data have been interpreted as a threefold band-population recurrence with Zak-phase separation near 2pi/3. This is a concrete mu=3 template, not a HOME prediction.")

add("T724","HOME three accesses versus Bloch mu=3",
    "REJECT NUMEROLOGY",True,
    "Equality of the integers 'three HOME access slots' and 'mu=3 Bloch recurrence' is not an alignment. The Bloch multiplier belongs to a band/Wilson-line realization fiber whose relation to HOME accesses is unestablished.")

add("T725","Topological-state recurrence versus elapsed-time multiplier",
    "SCOPE FIREWALL",True,
    "Finite state-space holonomy order does not by itself determine elapsed duration: topological braids may be executed at different admissible speeds.")

add("T726","Why topological Bloch remains strongest candidate class",
    "PASS / CANDIDATE RANKING",True,
    "Bloch transport combines internal symmetry/topological holonomy with a static-force progression scale, converting finite holonomy order directly into T_return/T_B=mu without a periodic drive.")

add("T727","Candidate-specific g_+ alignment condition",
    "PASS / NECESSARY GATE",True,
    "A candidate can test HOME only if the one-step operation identified as g_+ is fixed by independent operational data before the holonomy/timing result is inspected, and the internal fiber is attached to the same bearer lineage.")

add("T728","Universal HOME multiplier condition",
    "NO-GO WITH CURRENT PREMISES",True,
    "For HOME itself to predict mu, holonomy order must be constant across all realizations compatible with the retained Core. T714 and T716 give countermodels; current premises fail this.")

add("T729","Can a concrete candidate still yield a parameter-free holdout?",
    "YES, CONDITIONAL ON INDEPENDENT ALIGNMENT",True,
    "For a frozen candidate, independent structural identification of g_+ and fiber holonomy can yield a parameter-free multiplier. If standard candidate theory already fixes the same multiplier, this is a HOME consistency test, not novel prediction.")

add("T730","Strategic boundary after internal-fiber search",
    "NEW-PHYSICS FORK",True,
    "Known physics supplies strong holonomy and period-multiplication mechanisms, including mu=2 and mu=3. Current HOME lacks a Core-derived rule selecting realization-fiber holonomy. Closing the universal Novel-Prediction Gate now requires a new physical bridge/principle, or an independently motivated candidate-specific alignment that yields an observable not already implied by standard candidate theory.")

result={
 "summary":{"passed":sum(t["pass"] for t in tests),"total":len(tests),
            "failed":sum(not t["pass"] for t in tests)},
 "verdict":{
   "best_physical_candidate_class":"topological period-multiplied Bloch/Wilson-line transport",
   "observed_or_reported_multipliers_of_interest":[2,3],
   "core_holonomy_descent":"FAIL with current retained HOME premises",
   "s3_equivariance":"does not quantize mu; irreducible commuting action is projectively trivial, reducible commutant admits continuous relative phase",
   "spinor_anyon_status":"strong internal-holonomy templates but not elapsed-time laws",
   "home_three_equals_bloch_three":"numerology unless independent operational alignment is constructed",
   "novel_prediction_gate":"OPEN",
   "strategic_status":"NEW-PHYSICS FORK",
   "required_next_input":"new physical bridge/principle fixing realization-fiber holonomy from Core, or candidate-specific alignment independently justified and not already predictive in standard candidate theory"
 },
 "tests":tests
}
print(json.dumps(result,indent=2))
