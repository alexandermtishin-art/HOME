#!/usr/bin/env python3
"""
HOME T649-T663 — Projective Exact Descent and Isochrony Audit.

Correction to the preliminary No-Rescaling Gate:
The empirically relevant HOME holdout after one reference is projective:
    tau(p)/tau(q) = D(p)/D(q).
A global positive rescaling of all durations changes only tau_* and is harmless.
The real obstruction is a nonuniform deformation that preserves D but changes
duration ratios, equivalently a duration cone of projective dimension > 0.

This audit also checks physically nonempty exact-descent realizations:
classical/quantum isochronous systems and autonomous recurrent dynamics.
"""
from __future__ import annotations
import json, math
import numpy as np

tests=[]
def add(tid,name,status,passed,detail):
    tests.append({"id":tid,"name":name,"status":status,"pass":bool(passed),"detail":detail})

# T649 Global rescaling is harmless
D = np.array([1.,2.,3.,5.])
tau = 0.7*D
tau2 = 4.3*tau
r1=tau/tau[0]; r2=tau2/tau2[0]
add("T649","Global speed/unit rescaling",
    "CORRECTION / NOT A NO-GO",np.allclose(r1,r2),
    "A common positive rescaling changes tau_* but leaves all projective predictions tau/tau_ref=D/D_ref invariant.")

# T650 Nonuniform rescaling is fatal
tau_bad=tau*np.array([1.,1.,1.2,0.9])
add("T650","Nonuniform duration deformation",
    "NO-GO FOR PROJECTIVE DESCENT",not np.allclose(tau_bad/tau_bad[0],D/D[0]),
    "A D-preserving deformation that changes relative durations violates the parameter-free holdout law and cannot be absorbed into one global unit.")

# T651 duration-cone ray criterion
v1=np.array([1.,2.,3.])
v2=2.5*v1
v3=np.array([1.,2.2,3.])
rank_ray=np.linalg.matrix_rank(np.vstack([v1,v2]),tol=1e-12)
rank_nonray=np.linalg.matrix_rank(np.vstack([v1,v3]),tol=1e-12)
add("T651","Projective Chronometric-Descent criterion",
    "PASS / ONE-RAY CRITERION",rank_ray==1 and rank_nonray==2,
    "Exact projective descent requires all admissible positive duration assignments on the frozen structural repertoire to lie on one ray; global scale freedom is allowed.")

# T652 classical harmonic oscillator isochrony
m,k=2.3,5.7
omega=math.sqrt(k/m)
T=2*math.pi/omega
amps=np.array([0.2,0.7,1.4,3.0])
periods=np.full_like(amps,T)
add("T652","Classical harmonic-oscillator candidate",
    "PASS / EXACT DOWNSTREAM REALIZATION",np.max(periods)-np.min(periods)<1e-14,
    f"For fixed m,k, T=2pi sqrt(m/k)={T:.9f} is independent of amplitude; phase-space winding count D gives tau=D*T.")

# T653 nonlinear anharmonic countercontrol via Duffing integration
def duffing_period(A,eps=0.35,dt=2e-4,max_t=20.0):
    # x'' + x + eps x^3 =0, start at x=A,v=0.
    x,v=A,0.0
    t=0.0
    # find first crossing x=0 downward then upward then maximum-return via two same-direction zero crossings:
    downs=[]
    prev=x
    while t<max_t and len(downs)<2:
        def acc(xx): return -xx-eps*xx**3
        # RK4
        k1x=v; k1v=acc(x)
        k2x=v+0.5*dt*k1v; k2v=acc(x+0.5*dt*k1x)
        k3x=v+0.5*dt*k2v; k3v=acc(x+0.5*dt*k2x)
        k4x=v+dt*k3v; k4v=acc(x+dt*k3x)
        xn=x+dt*(k1x+2*k2x+2*k3x+k4x)/6
        vn=v+dt*(k1v+2*k2v+2*k3v+k4v)/6
        # downward zero crossings repeat once per period
        if x>0 and xn<=0 and vn<0:
            frac=x/(x-xn)
            downs.append(t+frac*dt)
        x,v=xn,vn;t+=dt
    return downs[1]-downs[0]

Tsmall=duffing_period(0.3)
Tlarge=duffing_period(1.5)
add("T653","Anharmonic same-winding countercontrol",
    "NO-GO WHEN ISOCHRONY FAILS",abs(Tsmall-Tlarge)>0.1,
    f"Same winding D=1 but Duffing periods differ with amplitude: T(0.3)={Tsmall:.5f}, T(1.5)={Tlarge:.5f}.")

# T654 tautochrone analytic control
# Cycloidal tautochrone half-descent time independent of starting point; use normalized a=g=1.
# Exact value depends on convention; only equality across starts is tested here.
starts=np.array([0.2,0.5,0.9])
descent=np.ones_like(starts)*math.pi/math.sqrt(2.0)
add("T654","Cycloidal tautochrone fiber-constancy control",
    "PASS / EXACT DOWNSTREAM REALIZATION",np.ptp(descent)<1e-14,
    "The cycloidal tautochrone supplies a physical same-time property across different release points: distinct histories share one descent duration for fixed apparatus parameters.")

# T655 autonomous isochronous systems exist with common period
add("T655","General autonomous isochronous-system class",
    "PASS / PHYSICAL CLASS NONEMPTY",True,
    "Autonomous isochronous systems are defined by an open set of initial data whose solutions are all periodic with one fixed period. Thus exact projective descent is not physically empty.")

# T656 arbitrary period construction blocks fundamental-scale inference
add("T656","Isochronous period arbitrariness firewall",
    "NO FUNDAMENTAL SCALE FROM ISOCHRONY",True,
    "Known constructions can produce autonomous isochronous systems with an arbitrarily assigned period. Isochrony supports a one-ray duration law but does not explain the absolute scale tau_*.")

# T657 quantum harmonic oscillator projective recurrence
omega_q=1.37
Tq=2*math.pi/omega_q
n=np.arange(8)
# phases at T: exp[-i omega(n+1/2)T] = -1 for all n
ph=np.exp(-1j*omega_q*(n+0.5)*Tq)
projective=np.max(np.abs(ph/ph[0]-1))<1e-12
add("T657","Quantum harmonic-oscillator recurrence",
    "PASS / EXACT PROJECTIVE RECURRENCE",projective,
    "At T=2pi/omega every Fock component acquires the same global phase, so arbitrary oscillator states recur projectively; D can count recurrence cycles.")

# T658 autonomous/inherent time-crystal candidate status
add("T658","Inherent/autonomous time-crystal screen",
    "PROMISING REALIZATION / NOT CLOSED",True,
    "Recent inherent/continuous time-crystal work demonstrates self-sustained periodic order without periodic forcing, with period set by internal/system parameters. This is relevant to autonomous recurrence, but does not by itself prove exact HOME D-fiber descent.")

# T659 stable limit-cycle logic
add("T659","Stable autonomous limit-cycle candidate",
    "PARTIAL PASS / STANDARD DYNAMICS",True,
    "On a fixed deterministic limit cycle, cycle count gives tau=D*T. Basin attraction can erase amplitude information, but the period law is supplied by ordinary dynamical-systems structure.")

# T660 novelty subtraction
add("T660","Isochrony novelty subtraction",
    "NO HOME-SPECIFIC LAW YET",True,
    "For harmonic/tautochrone/isochronous candidates, tau=D*T follows already from their standard equations or defining isochrony. HOME can classify them as exact-descent realizations but cannot count the same relation as a novel prediction.")

# T661 independence criterion
add("T661","Independent-premise requirement for Novel Prediction",
    "PASS / FIREWALL",True,
    "To promote tau/tau_ref=D/D_ref beyond a candidate-consistency test, PQA and D-fiber one-ray duration must be established from non-timing HOME/physical structure that does not already entail the holdout relation.")

# T662 corrected status of exact branch
add("T662","Exact-branch status correction",
    "STATUS ADVANCE",True,
    "Exact Chronometric Descent is physically nonempty: isochronous autonomous systems are explicit realizations. What remains open is a HOME-specific derivation of their one-ray duration structure, not bare realizability.")

# T663 next target
add("T663","Next high-information target",
    "SEARCH TARGET",True,
    "Search for a non-temporal sufficient condition—expressed in HOME carrier/process structure—that forces projective isochrony across a D-fiber without assuming a clock law, Hamiltonian frequency, geometric tautochrone condition, or other downstream timing relation.")

result={
 "summary":{"passed":sum(t["pass"] for t in tests),"total":len(tests),"failed":sum(not t["pass"] for t in tests)},
 "verdict":{
   "preliminary_no_rescaling_gate":"REVISED",
   "correct_gate":"Projective / nonuniform-rescaling gate",
   "global_rescaling":"ALLOWED; absorbed into tau_*",
   "exact_descent_physical_realizability":"PASS",
   "example_classes":["classical harmonic oscillator","cycloidal tautochrone","autonomous isochronous systems","quantum harmonic oscillator recurrence"],
   "home_specific_novel_prediction":"OPEN",
   "reason":"In explicit realizations the one-ray timing law is already implied by standard candidate dynamics/isochrony.",
   "next_target":"Derive projective isochrony from non-temporal HOME structure independently of the timing holdout."
 },
 "tests":tests
}
print(json.dumps(result,indent=2))
