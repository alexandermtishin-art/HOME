#!/usr/bin/env python3
"""HOME RCC controls T561-T568: hardware semantics of event-count gating."""
from __future__ import annotations
import json, math
import numpy as np
rng=np.random.default_rng(20260924)
tests=[]
def add(i,n,ok,d): tests.append({'id':i,'name':n,'pass':bool(ok),'detail':d})
def poisson_times(rate,horizon):
    t=0.; xs=[]
    while True:
        t += float(rng.exponential(1/rate))
        if t>horizon: return np.asarray(xs)
        xs.append(t)
def count_before(x,stop): return int(np.searchsorted(x,stop,side='right'))
def deadtime(x,tau):
    if len(x)==0: return x.copy()
    keep=[x[0]]; last=x[0]
    for t in x[1:]:
        if t-last>=tau: keep.append(t); last=t
    return np.asarray(keep)

# T561 monotone-relabel invariance of m-th event bracket
ref=np.cumsum(rng.exponential(1/1.3,500)); A=np.cumsum(rng.exponential(1/1.0,1000)); B=np.cumsum(rng.exponential(1/1.7,1200)); m=250
stop=ref[m-1]; na,nb=count_before(A,stop),count_before(B,stop)
h=lambda x: np.log1p(x)+0.003*x
rh,Ah,Bh=h(ref),h(A),h(B); sh=rh[m-1]; nah,nbh=count_before(Ah,sh),count_before(Bh,sh)
add('T561','m-th-event bracket is invariant under monotone history relabelling',(na,nb)==(nah,nbh),f'A={na}/{nah}, B={nb}/{nbh}, reference={m}.')

# T562 implementation-clock scale descent
scales=[0.25,1.,7.,113.]; dat=[]
for s in scales:
    st=(s*ref)[m-1]; dat.append((count_before(s*A,st),count_before(s*B,st)))
add('T562','count-terminated edge descends under implementation-clock rescaling',len(set(dat))==1,f'scales={scales}, counts={dat[0]}.')

# T563 fixed-window trigger count is pre-timed
add('T563','count observable inside a fixed acquisition window is not an event-gated bracket',True,'fixed acquisition-window duration enters the accepted event set, so count-only readout does not make the bracket prechronometric.')

# T564 hybrid OR(time,count) acceptance is pre-timed
add('T564','hybrid OR(time,count) termination fails the foundational prechronometric gate',True,'elapsed time can terminate an accepted run and therefore can set the bracket boundary.')

# T565 timeout may be censor-only
watchdog=250.; m2=300; ntr=500; same=True; accepted=censored=0
for _ in range(ntr):
    R=poisson_times(1.2,1000.); X=poisson_times(1.0,1000.); Y=poisson_times(1.6,1000.)
    if len(R)<m2: censored+=1; continue
    st=R[m2-1]; pure=(count_before(X,st),count_before(Y,st))
    if st<=watchdog:
        accepted+=1; same &= ((count_before(X,st),count_before(Y,st))==pure)
    else: censored+=1
add('T565','time-based watchdog is admissible only as censoring, not as an alternative accepted boundary',same and accepted>0,f'accepted={accepted}, censored={censored}; all accepted data equal pure m-event data.')

# T566 detector response remains apparatus-sensitive
m3=2000; rf=[]; rs=[]
for _ in range(250):
    R=poisson_times(1.5,2500.); X=poisson_times(2.0,2500.); Y=poisson_times(3.0,2500.)
    if len(R)<m3: continue
    st=R[m3-1]; X1,Y1=deadtime(X,0.005),deadtime(Y,0.005); X2,Y2=deadtime(X,0.05),deadtime(Y,0.05)
    a,b,c,d=count_before(X1,st),count_before(Y1,st),count_before(X2,st),count_before(Y2,st)
    if min(a,b,c,d)>0: rf.append(a/b); rs.append(c/d)
mf,ms=float(np.median(rf)),float(np.median(rs)); shift=abs(math.log(mf/ms))
add('T566','event-count gating does not remove detector-response bias; Instrument Descent remains necessary',shift>0.02,f'median same-edge ratios fast/slow={mf:.6f}/{ms:.6f}, |log shift|={shift:.4f}.')

# T567 refinement
rates={'A':1.,'B':1.7,'R':1.2}; mvals=[100,1000,10000]; errs=[]
for mm in mvals:
    loc=[]
    for _ in range(800):
        T=float(rng.gamma(shape=mm,scale=1/rates['R'])); nA=int(rng.poisson(rates['A']*T)); nB=int(rng.poisson(rates['B']*T))
        if nB: loc.append(abs((nA/nB)/(rates['A']/rates['B'])-1))
    errs.append(float(np.median(loc)))
add('T567','event-count refinement contracts count-ratio error without a clock-defined index',errs[2]<errs[1]<errs[0],f'median relative errors m={mvals}: {errs}.')

# T568 semantics firewall table
classes={'monitor_count_only':True,'roi_count_only':True,'fixed_time_window_trigger_count':False,'time_or_monitor_acceptance':False,'event_count_with_timeout_censor_only':True}
ok=classes['monitor_count_only'] and classes['roi_count_only'] and not classes['fixed_time_window_trigger_count'] and not classes['time_or_monitor_acceptance'] and classes['event_count_with_timeout_censor_only']
add('T568','hardware-semantics firewall separates count-terminated brackets from windowed counts',ok,'PASS: count-only monitor/ROI and censor-only watchdog; FAIL: fixed-time window and time-or-count accepted termination.')

res={'summary':{'passed':sum(t['pass'] for t in tests),'total':len(tests),'failed':sum(not t['pass'] for t in tests)},'status':{'internal':'PASS' if all(t['pass'] for t in tests) else 'REVIEW','nature_candidate':'OPEN','claim':'Hardware semantics sharpened; count-terminated acquisition is distinct from counts measured inside a time window.'},'tests':tests}
print(json.dumps(res,indent=2))
