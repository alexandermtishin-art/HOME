#!/usr/bin/env python3
from __future__ import annotations
import json
import numpy as np

tests = []
def add(tid, name, status, passed, detail):
    tests.append({"id":tid,"name":name,"status":status,"pass":bool(passed),"detail":detail})

# T623 — Exact descent criterion
same_D_durations = np.array([3.0, 3.0, 3.0])
var0 = float(np.var(same_D_durations))
add("T623","Exact Chronometric-Descent fiber criterion",
    "PASS / NECESSARY AND SUFFICIENT FINITE-FIBER TEST", var0 == 0.0,
    "Exact factorization tau=tau_bar∘D requires tau to be constant on each D-fiber; equivalently Var(tau|D)=0 for deterministic finite samples.")

# T624 — Poisson/renewal spontaneous counting fails exact descent
rng = np.random.default_rng(20260924)
lam = 2.0
n = 5
samples = rng.gamma(shape=n, scale=1/lam, size=200000)
emp_var = float(np.var(samples))
theory_var = n/(lam**2)
add("T624","Spontaneous renewal-count candidate",
    "NO-GO FOR EXACT DESCENT", abs(emp_var-theory_var)/theory_var < 0.02 and emp_var > 0,
    f"For n={n} Poisson/renewal arrivals, S_n is Gamma/Erlang with Var=n/lambda^2={theory_var:.6f}; simulation Var={emp_var:.6f}. Same D=n has nonzero duration spread.")

# T625 — Mean-only repair is standard renewal theory
means = []
for nn in [1,2,4,8]:
    s = rng.gamma(shape=nn, scale=1/lam, size=100000)
    means.append(float(np.mean(s)))
linear = np.allclose(np.array(means), np.array([1,2,4,8])/lam, rtol=0.015)
add("T625","Replace exact descent by E[tau|D] proportional to D",
    "REJECT AS HOME-SPECIFIC PREDICTION", linear,
    "Mean duration is linear in event count for iid renewal increments, but this is standard renewal statistics and requires a rate/interval law; it does not establish exact Chronometric Descent.")

# T626 — Atomic-clock cycle count
cycles = np.array([1,2,3,10], dtype=float)
period = 1/9_192_631_770.0
tau = period*cycles
add("T626","Atomic-clock cycle-count candidate",
    "DOWNSTREAM CONTROL / FOUNDATIONAL CIRCULARITY", np.allclose(tau/tau[0], cycles),
    "Cycle count gives exact proportional duration only after selecting the atomic resonant period as the time standard. It demonstrates realizability of count-based timing, not an independent derivation of Chronometric Descent.")

# T627 — Josephson frequency-voltage relation
f = np.array([1.0,2.0,5.0])
K = 483597.9
V = f/K
add("T627","Josephson quantized-step candidate",
    "DOWNSTREAM / TIME IMPORTED", np.allclose(V/V[0], f/f[0]),
    "The Josephson metrological law relates voltage steps to applied frequency. The integer/quantized structure is real, but calibrated frequency/time already enters the physical law.")

# T628 — Rabi-cycle candidate
Omega1, Omega2 = 1.0, 1.7
D = 4
tau1, tau2 = D*2*np.pi/Omega1, D*2*np.pi/Omega2
add("T628","Rabi-cycle candidate",
    "NO-GO FOR INDEPENDENT DESCENT", not np.isclose(tau1,tau2),
    f"Same cycle count D={D} gives durations {tau1:.6f} and {tau2:.6f} under different drive strengths; the timing scale is selected by Hamiltonian/drive parameters.")

# T629 — Floquet / discrete-time-crystal candidate
Tdrive1, Tdrive2 = 1.0, 1.3
subharmonic_multiplier = 2
resp1 = subharmonic_multiplier*Tdrive1
resp2 = subharmonic_multiplier*Tdrive2
add("T629","Floquet/time-crystal integer-period candidate",
    "DOWNSTREAM / EXTERNAL PERIOD IMPORTED", not np.isclose(resp1,resp2),
    "Integer/subharmonic temporal order is tied to an externally imposed Floquet drive period; changing the drive changes the response period while preserving the integer multiplier.")

# T630 — repeated-cell traversal
Dcells = 5
length = 1.0
v1, v2 = 2.0, 3.0
t1, t2 = Dcells*length/v1, Dcells*length/v2
add("T630","Repeated spatial-cell traversal candidate",
    "NO-GO WITHOUT DOWNSTREAM KINEMATICS", not np.isclose(t1,t2),
    "D can be fixed by cell count, but tau requires metric length and propagation speed. Same D admits different durations, so exact descent is not supplied by objecthood alone.")

# T631 — digital pulse train
clock_periods = [1.0, 1.5]
Dpulse = 8
durations = [Dpulse*T for T in clock_periods]
add("T631","Engineered digital pulse-train candidate",
    "ENGINEERED CONTROL / EXTERNAL CLOCK", durations[0] != durations[1],
    "Pulse count is exact, but proportional duration is imposed by the hardware clock period. Useful control, not an independent natural HOME realization.")

# T632 — topological winding count
winding = 3
omega_a, omega_b = 2.0, 5.0
ta = 2*np.pi*winding/omega_a
tb = 2*np.pi*winding/omega_b
add("T632","Topological winding-count candidate",
    "NO-GO: TOPOLOGY DOES NOT FIX DURATION", not np.isclose(ta,tb),
    f"Same winding D={winding} admits tau={ta:.6f} or {tb:.6f} under different phase speeds. Integer topology alone does not supply Chronometric Descent.")

# T633 — general candidate dichotomy
add("T633","Natural-candidate dichotomy",
    "PASS / GENERAL FILTER", True,
    "Audited candidates split into: (a) timing-independent event counts with nonzero duration spread at fixed D, failing exact descent; or (b) exact count-duration locking produced by an already selected clock/drive/dynamics, making the lock downstream rather than independently HOME-derived.")

# T634 — integrated strategic verdict
add("T634","Integrated natural-realization verdict",
    "STRATEGIC FORK / NO CANDIDATE CLOSED", True,
    "The conditional law tau=tau_*D remains mathematically nontrivial and survives RCC subtraction, but no audited natural candidate independently establishes both PQA-like one-ray progression and exact Chronometric Descent. No new postulate is introduced.")

result = {
    "summary":{
        "passed":sum(t["pass"] for t in tests),
        "total":len(tests),
        "failed":sum(not t["pass"] for t in tests)
    },
    "verdict":{
        "conditional_prediction_template":"tau=tau_*D",
        "exact_descent_fiber_test":"Var(tau|D)=0",
        "natural_candidate_closed":False,
        "mean_only_repair":"rejected_as_standard_renewal_theory",
        "novel_prediction_gate":"OPEN",
        "strategic_fork":[
            "Keep exact Chronometric Descent and continue searching for a non-clock-defined deterministic physical progression.",
            "Weaken to statistical/expectation descent, accepting extra stochastic premises and that the linear-count law is largely standard renewal theory."
        ]
    },
    "tests":tests
}
print(json.dumps(result, indent=2))
