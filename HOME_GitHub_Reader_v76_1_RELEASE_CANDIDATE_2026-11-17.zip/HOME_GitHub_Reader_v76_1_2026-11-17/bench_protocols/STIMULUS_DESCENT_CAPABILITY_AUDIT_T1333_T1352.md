# HOME T1333–T1352 — Stimulus-Descent and Capability Audit

## Access-vs-State correction

Eight molecular states are not enough for HOME `B3`.

Each armed axis must open a **bearer-dependent future-response capability**.

The eight-state receptor survives this kill test provisionally because the published chemistry
supplies a plausible future-response witness for each dimension:

- guest coordination changes subsequent electrochemical/optical response;
- acridinium → acridane switching changes subsequent photophysics and other molecular
  responses;
- porphyrin oxidation changes subsequent guest-binding affinity.

Thus the cube is not merely three arbitrary labels.

But finite observed markers do not prove exact non-simulability of the three full access
repertoires.

## Stimulus-Descent problem

A single-molecule classifier could appear to distinguish eight contexts simply because it reads:

- free 4,4'-bipyridine in solution;
- TBAOH/TFA or related ionic/dielectric changes;
- electrochemical gate feedthrough.

That would fail HOME anti-vacuity.

## Corrected frozen vector

Keep the fixed electrical+Raman target vector, but add a preregistered control layer.

Define schematically

`R_bearer = R_target - background_model(reference devices, stimulus)`.

The background model is learned on calibration/control devices and frozen before the blinded
target validation.

Only responses also present in matched controls may be subtracted. Receptor-dependent
coordination and environment-coupled molecular responses remain physical.

## Preferred controls

An empty junction is useful but may be insufficient.

Prefer near-isogenic controls that preserve the anchoring/scaffold while disabling a responsive
element, because molecular environments can couple to electrodes even without the target
switching event.

A small preregistered control panel may be necessary for the three different stimulus classes.

## Strict pass condition

After stimulus/background descent, all eight target contexts must remain response-distinct
under the same frozen electrical+Raman vector and one global metric.

If the eightfold separation collapses after correction, the receptor remains an interesting
eight-state chemical switch but is not a verified HOME `B3` realization under the declared
response repertoire.
