# HOME T1293–T1312 — Pre-registered B3 + Pre-UPO Measurement Matrix

## Purpose

Turn the current HOME frontier into a falsifiable single-bearer bench protocol **without**
introducing TADE, OFAT, `G=1`, or a desired recurrence as inputs.

The static context code is

`G N R in {0,1}^3`

where the bits denote the three preregistered armed branches:
guest-recognition, nucleophile/acridane switching, and redox state.

## Stage 0 — instrument and lineage controls

For each of eight contexts:

- verify repeated readout does not itself change the context;
- verify the same molecule-specific bearer fingerprint before and after the measurement cycle.

Failure here stops the same-bearer claim.

## Stage 1 — strict B3 audit

### Anti-vacuity

Each of the three arming maps is tested on the four cube edges where its bit begins at zero.

Total: **12 edge tests**.

Every edge must open/change a bearer-dependent future-response capability under the same
frozen response repertoire.

### Idempotence

For each `E_i` and each of eight starting contexts:

`E_i(E_i(C)) ~ E_i(C)`.

Total: **24 tests**.

### Commutativity

For every unordered pair `(i,j)` and every starting context:

`E_i E_j(C) ~ E_j E_i(C)`.

Total: **24 comparison units**.

Both orders must also match the preregistered target cube vertex.

### Eight-state distinctness

All eight final context fingerprints must be mutually distinguishable under one fixed metric.
Passing the twelve nearest-neighbour edges alone is not sufficient.

Equivalence/distinctness margins must be frozen from null/repeatability calibration before
holdout data are inspected. HOME itself supplies no universal `sigma` threshold.

## Stage 2 — independent Pre-UPO candidate

Use one fourth operation: a frozen optical trigger.

Apply the **same procedure and event criterion** to all eight static contexts.

The oxidized (`R=1`) vertices are a blind holdout.

A fixed femtosecond window is not an admissible event definition by itself. A Pre-UPO candidate
must have a physically identifiable bearer event boundary and a non-idempotent retained action.

A real optical history occurrence that simply relaxes back to the same retained action class
does not pass.

If the Pre-UPO gate fails, stop. A successful B3 experiment remains valuable on its own.

## Stage 3 — alignment

Only after independent B3 and Pre-UPO success:

- construct the candidate-specific d=4 ↔ HOME action/response alignment;
- do not use a desired unit grade to choose the mapping.

## Stage 4 — blind UPO test

Evaluate

`G = D o pi`.

`G=1` is an output.

If `G != 1`, the candidate is not a UPO even if the static B3 and Pre-UPO gates passed.

## Stage 5 — dynamic holdout

Only after `G=1`:

freeze the B3 readouts and measure what one UPO actually does.

No branch is assumed:
- persistent;
- reset;
- permutation;
- or something outside all proposed branches.

This is where TADE/OFAT would finally face data rather than being inserted as postulates.

## Matrix size

The attached CSV contains **84 preregistered measurement/control rows**:

- 8 readout-null controls;
- 8 lineage controls;
- 12 anti-vacuity cube edges;
- 24 idempotence tests;
- 24 commutativity comparison units;
- 8 optical Pre-UPO context tests.

The protocol is logically noncircular. Its dominant practical risk is that single-molecule
immobilization/junction integration may destroy or merge the solution-state eight-context
structure, in which case the experiment correctly terminates at Stage 1.
