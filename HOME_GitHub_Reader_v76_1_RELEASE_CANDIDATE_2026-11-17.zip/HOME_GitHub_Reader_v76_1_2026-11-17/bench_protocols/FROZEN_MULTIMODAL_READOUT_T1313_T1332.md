# HOME T1313–T1332 — Frozen Multimodal Readout

## Problem solved at the protocol level

HOME does **not** require one scalar observable. It requires one frozen response repertoire.

The current best minimal readout is therefore a fixed multimodal vector

`R(C) = I(V-grid) ⊕ S_Raman(omega-grid)`,

where:
- all bias points are fixed before the blinded context test;
- the Raman wavelength, power, polarization, integration and spectral grid are fixed;
- one global metric/classifier is used for every one of the eight contexts.

No vertex-specific peak choice, threshold, feature weighting or instrument retuning is allowed.

## Why these two modalities

Single-molecule experiments already demonstrate simultaneous Raman/SERS and electrical
conductance/I-V measurements.  The two channels are complementary:
- electrical transport is sensitive to redox/electronic structure and coordination;
- Raman supplies molecular, coordination and geometry fingerprints.

The receptor chemistry independently shows that guest binding and acridinium/acridane/redox
changes alter electronic and spectroscopic properties, making this combination physically
plausible for eight-state discrimination.

## Global response metric

Use repeated null reads to estimate one pooled within-context covariance.

Freeze a single global distance/classification rule before the confirmatory block.

Then acquire a separate blinded validation block.

The experiment fails if any two contexts remain response-degenerate under this frozen rule.

No universal numerical HOME threshold is asserted; the laboratory false-match/error criterion is
an engineering preregistration choice derived from null/repeatability calibration.

## Back-action gates

### Electrical

Choose the read window on sacrificial/calibration devices below any observed switching/redox
threshold, then freeze it.

### Raman

Use one weak/off-resonant read beam. Repeated exposure must not change context or lineage.

The weak Raman read operation must be experimentally distinct from the later optical Pre-UPO
trigger. Otherwise measurement and progression are conflated.

## Critical device constraint

Do not use the Zn axial sites as the electrode anchoring geometry if those same sites are needed
for 4,4'-bipyridine recognition.

Anchoring should be peripheral/covalent or otherwise leave the recognition cavity available.

Any anchor-modified receptor is a new physical realization, so its full eight-context B3 must be
re-audited rather than imported from the solution molecule.

## Failure policy

If electrical+Raman is insufficient to separate all eight contexts, the current protocol fails.

A third modality may be considered only under a **new preregistration**, not patched into the
same experiment after inspecting which vertices collided.
