# HOME T1149–T1166 — UPO Alignment Circularity Audit

## The problem

`G=D o pi` is exact only after the structural progression grade `D` has been physically
activated on the aligned HOME action quotient.

But activation itself already requires an independently established same-bearer non-idempotent
physical witness.

Therefore a `G=1` occurrence cannot be used to discover or justify the very alignment from
which `G` is obtained.

## Repair: Pre-UPO

Define a **Pre-UPO candidate** before alignment:

> a physically non-null same-bearer occurrence/process whose non-idempotence and event
> criterion are established without using `D`, `G`, elapsed time, a period, or a desired
> access recurrence.

Then use the following order.

### Stage A — physical candidate

Identify the bearer, lineage, event criterion, non-idempotence, apparatus and partner/drive
dependence without `D`.

### Stage B — alignment

Construct and test the candidate-specific HOME ↔ d=4 action/response alignment.

### Stage C — grade test

Only after `D` is available evaluate

`G = D o pi`

on realized occurrences.

The candidate becomes a UPO only if `G=1` is well-defined and stable across its declared
realization class.

### Stage D — downstream physics

Then test intrinsicness, partner descent and the effect of one UPO on `B3`.

## What survives

The UPO theorem survives unchanged:

`G=1` forbids a decomposition into two positive-grade suboccurrences.

The correction concerns epistemic order, not the theorem.

## Reclassification

- branch-conditioned single-ion transition: **Pre-UPO candidate**;
- superconducting phase slip: **Pre-UPO candidate**.

Neither has yet earned the label `G=1`.

No new postulate is introduced.
