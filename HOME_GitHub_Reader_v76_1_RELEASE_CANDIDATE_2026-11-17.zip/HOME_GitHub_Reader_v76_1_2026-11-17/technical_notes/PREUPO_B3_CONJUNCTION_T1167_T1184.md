# HOME T1167–T1184 — Pre-UPO + B3 Conjunction Audit

## The corrected Nature gate

The physical candidate must establish two structures **independently** before common-skeleton
alignment is tested.

### A. Genuine `B3`

Three carrier-coupled future-capability access families, all eight subset contexts physically
distinct, with non-vacuous arming. External bookkeeping switches do not count.

### B. Pre-UPO

A physically non-null same-bearer non-idempotent occurrence whose event criterion is defined
without `D`, `G`, a clock period or a desired recurrence.

## Candidate matrix

- single ion: strong Pre-UPO, no audited B3;
- superconducting phase slip: strong Pre-UPO, no audited B3;
- F1-ATPase: strong repeatable process, no independent B3;
- holonomy systems: strong structural step, state/access gap;
- three-station rotaxane: strong recognition-access semantics, but only two independently
  switchable stations in the strongest audited [2]rotaxane;
- three-port circulator: strong independent channels, but no intrinsic same-bearer Pre-UPO.

The 2026 coupled [3]rotaxane enriches the machine but does not automatically increase the
Boolean control rank; coupled motion actually makes exact access factorization a harder claim.

## Result

No audited single physical bearer currently closes

`genuine B3 + independent same-bearer Pre-UPO`.

This conjunction is the precise Nature bottleneck.

Only after it is closed should one test the d=4↔HOME common-skeleton alignment, obtain `D`,
evaluate `G=D o pi`, and ask whether the occurrence is a UPO.
