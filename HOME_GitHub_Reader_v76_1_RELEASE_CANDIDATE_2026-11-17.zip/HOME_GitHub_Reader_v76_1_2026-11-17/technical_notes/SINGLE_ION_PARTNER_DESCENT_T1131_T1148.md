# HOME T1131–T1148 — Single-Ion Partner-Descent Audit

## Physical test

Use the same trapped `40Ca+` ion while changing the optical-cavity environment.

The cavity modifies the `P1/2 -> D3/2` channel and simultaneously changes the competing
`P1/2 -> S1/2` fluorescence.  Therefore the environment changes a **bearer-side future
response profile**, not merely an external photon label.

## Main negative result

A broad bearer event type such as

`decay from P1/2`

does **not** descend exactly across near- and far-detuned cavity environments if the bearer
context includes branching/fluorescence responses.

The initial bearer label is the same, but the future response structure is not.

## Narrow branch-conditioned type

A narrower event

`P1/2 -> D3/2`

remains an identifiable bearer transition across environments.  If `C_b` asks only for the
post-event internal ion state, partner-specific realizations may be quotient-identified.

But this is a restricted claim.  Equal terminal level labels do not by themselves prove an
exact contextual congruence under all future bearer continuations.

One controlled way to test descent is to reset the environment to a common reference after
the event and then apply the same continuation family.  The reset itself must not be declared
zero-grade without an independent HOME alignment.

## HOME status

This is a strong **Bearer-Typed Relational pre-UPO** testbed.

It does not yet establish:
- HOME primitive status;
- structural grade `G=1`;
- exact full-process bearer descent.

The experiment is already useful because it kills the overly broad claim that environment
dressing merely changes rates while leaving all bearer-side responses unchanged.
