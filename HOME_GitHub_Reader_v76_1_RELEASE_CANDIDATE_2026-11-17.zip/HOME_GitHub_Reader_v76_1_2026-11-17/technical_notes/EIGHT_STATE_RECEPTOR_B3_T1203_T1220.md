# HOME T1203–T1220 — Eight-State Molecular Receptor as a B3 Candidate

## Why this is a stronger candidate

A bis(acridinium–Zn(II) porphyrin) receptor has been experimentally reported with **eight
distinct molecular states** organized as a cube with three orthogonal stimulus dimensions.

The dimensions correspond to physical molecular responses:
- guest recognition/binding;
- acridinium ↔ acridane chemical switching with major photophysical change;
- redox/electronic switching.

This is substantially stronger than merely having three external buttons.

## HOME gates already supported

- one persistent molecular bearer;
- control rank three;
- eight distinct contexts;
- non-vacuous bearer-dependent response on each axis;
- reversible chemical switching on at least one axis.

## What is still missing for strict B3

HOME needs exact capability-level arming maps `E_i` satisfying

`E_i^2 = E_i`

and

`E_i E_j = E_j E_i`

for every relevant context.

The chemistry paper is not an all-eight-context algebra audit.  Orthogonal stimuli and a cubic
state diagram make the hypothesis plausible, but they do not replace pairwise order tests and
repeat-arm tests under a frozen response repertoire.

Quantitative cross-coupling between axes does not automatically kill B3: the Boolean statement
is about exact closure classes of available future capabilities, not equality of kinetics,
binding constants or redox potentials.

## Progression side

The receptor does **not** yet supply the positive progression candidate.

One must not simply choose an edge of the eight-state cube and call it `g_+`; that would relabel
one static access operation as progression.

The Pre-UPO must be independently defined as a same-bearer non-idempotent occurrence before
alignment.

## Experimental completion of the static side

For all eight contexts:

1. freeze one common probe/readout repertoire;
2. apply each arming operation twice and test closure idempotence;
3. for each pair `(i,j)`, compare `E_i E_j` with `E_j E_i`;
4. prohibit retuning of the response criterion across contexts.

If those tests pass, this existing molecule becomes a serious physical realization of HOME
static `B3`.

The missing conjunction would then be sharply reduced to adding/finding an independent
Pre-UPO on the same bearer.
