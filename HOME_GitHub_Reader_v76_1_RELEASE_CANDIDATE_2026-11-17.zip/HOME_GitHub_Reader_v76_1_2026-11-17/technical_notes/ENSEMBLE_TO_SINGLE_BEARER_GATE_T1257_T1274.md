# HOME T1257–T1274 — Ensemble-to-Single-Bearer Gate

## Published experiment

The eight-state receptor photophysics is measured in solution with micromolar samples and
pulsed ensemble spectroscopy.

This is excellent for distinguishing photophysical mechanism classes, but it is not an
occurrence ledger for one molecule.

## HOME consequence

`H_occ` requires realized occurrence/history tokens.

An ensemble transient absorption trace does not say which particular receptor absorbed,
whether the same receptor is followed across repeated events, or whether one molecule
traversed the prepared contexts.

Thus:

**ensemble optical action tomography != same-bearer Pre-UPO realization.**

## What ensemble data still establish

They remain scientifically useful:

- they support response-distinct static molecular contexts;
- they distinguish electron-transfer from ISC/energy-transfer dynamics;
- they already falsify the full optical excursion as one common action across measured
  contexts.

## Repair

For the progression side, use one tagged/immobilized receptor or another lineage-resolved
implementation.

The same bearer must support:
1. reversible verification of static context;
2. one optical trigger independent of the three B3 arming axes;
3. event-conditioned readout;
4. pre/post bearer identity/fatigue controls;
5. repetition on the same molecule.

Single-porphyrin junction work in the broader molecular family shows that individual porphyrin
molecules can be electrically addressed and charge-switched, but this is only a feasibility
template, not evidence that the present eight-state receptor already supports such a setup.

## Status

The receptor remains the strongest current static B3 bench candidate.

Its published optical data do not yet provide a same-bearer Pre-UPO.

The next gate is therefore lineage-resolved implementation, not another ensemble kinetic fit.
