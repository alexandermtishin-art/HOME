# HOME T1275–T1292 — Single-Bearer Bench Feasibility

## Existing enabling technologies

Porphyrin single-molecule junction experiments already demonstrate several pieces needed by
the HOME bench:

- individual porphyrin electrical addressing;
- reversible charge-state switching;
- proton-transfer multistate switching;
- stable junction lifetimes long enough for repeated measurements;
- supramolecular/axial coordination that changes single-molecule conductance.

Therefore a lineage-resolved porphyrin device is physically plausible.

## Critical firewall

The existing eight-state receptor has **not** been demonstrated in such a device.

More importantly, anchoring is not a harmless readout layer. Electrodes and linkers change
conformation, orbital coupling and charge transport.

So the solution-state cube cannot simply be imported.

After device integration, strict `B3` must be re-established from zero:
- all eight contexts;
- anti-vacuity;
- repeat-arm idempotence;
- pairwise order independence;
- stable bearer identity.

## Minimal integrated device

A plausible architecture is:

- one covalently anchored receptor in a stable nanogap / graphene-style junction;
- low-bias conductance as nondestructive lineage/context monitor;
- independent electrochemical gate for redox arming;
- fluidic access for guest binding and acid/base/nucleophile switching;
- optical access as the fourth, progression-candidate channel;
- event-conditioned electrical/optical readout.

The read and write operations must be separated so that conductance measurement does not
itself define one access axis.

## Status

The experiment is **engineering-plausible in components** but not yet an existing integrated
device.

This is now a concrete bench-development problem rather than an undefined search for a
physical candidate.
