# HOME T987–T1004 — Unit Progression Occurrence (UPO)

## Existing structures

HOME already contains the occurrence projection

`pi : H_occ -> P_H`

and, on the aligned activated branch, the structural progression grade

`D : P_H -> N0`.

Define the occurrence grade

`G := D o pi`.

This is structural progression count, not elapsed time.

## Unit Progression Occurrence

A physically non-null same-bearer realized occurrence `h` is a **UPO** when

`G(h)=1`.

## Positive indecomposability

If `h=b o a` and `G(h)=1`, additivity gives

`G(a)+G(b)=1`.

Since both terms are non-negative integers, both cannot be positive. More generally, any finite factorization of a UPO contains at most one positive-grade factor; all other factors have grade zero.

Thus UPO is **elementary with respect to positive progression, modulo zero-grade physical dressing**.

## Important firewalls

UPO does not imply microscopic atomicity. Grade-zero preparation, access, interaction, apparatus or other implementation details may remain physically real.

Different UPO tokens remain distinct in `H_occ`; `G=1` does not imply equal elapsed duration.

PQA, if additionally valid, sharpens the action quotient to one unit process class `tau_prog`, but UPO itself does not require PQA.

No statement about `B3`, TADE or OFAT is used.

## Remaining Nature gate

An externally commanded operation can also satisfy `G=1`.

So HOME now has a clean no-new-postulate definition of one positive progression step, but still lacks a theorem that Nature supplies an **intrinsic/autonomous same-bearer UPO**.
