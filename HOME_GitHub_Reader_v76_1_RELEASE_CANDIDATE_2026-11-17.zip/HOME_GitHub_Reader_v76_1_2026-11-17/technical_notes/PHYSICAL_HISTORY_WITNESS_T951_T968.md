# HOME T951-T968 — Physical History Witness (PHW)

## Correction to PRR

T933-T950 correctly separated projected recurrence from complete-history non-return, but the
phrase **residual record** was too strong if interpreted as a persistent memory present after
the cycle.

HOME's existing complete contextual-response criterion explicitly allows a physical difference
to be revealed by:

- a later continuation;
- a side coupling;
- an independently accessible intermediate boundary.

A transient intermediate difference can therefore be physical even when **no final record
remains**.

## Correct exact statement

For a strict history extension to represent a physical rather than merely formal distinction,
there must be at least one admissible contextual witness somewhere in its complete response
profile.

Call this the **Physical History Witness (PHW)** condition.

If no admissible continuation, side coupling, or intermediate probe can distinguish an alleged
extra refinement, that refinement is counterfactually null and should disappear in the exact
physical quotient.

## Projected recurrence still survives

Suppose a projected access state returns:

`a(H_n)=a(H_0)`.

If the intervening strict history extensions were physically non-null, then the access
projection has erased some occurrence information.

But that information need not be stored at the final boundary.  It may have been accessible
only while the occurrence was taking place.

Therefore:

**projected recurrence does not imply persistent memory.**

## Consequences

HOME does not derive:

- an internal cycle counter;
- an environmental memory;
- a persistent apparatus record;
- entropy production;
- a Landauer cost.

An apparatus may create a durable record of a transient distinction, but bearer-only
attribution then requires Instrument Descent.

## Repaired experimental gate

For every recurrent candidate classify separately:

1. terminal access recurrence;
2. later-response witness;
3. side-coupling witness;
4. intermediate-only witness;
5. persistent bearer/environment/apparatus record;
6. disturbance introduced by the witness.

This replaces the overly strong Record-Location Gate by a **History-Witness Classification**.

## Status

No new postulate is introduced.

The exact retained statement is:

> A physically non-null history extension requires an admissible contextual witness somewhere;
> the witness need not survive as a terminal memory.

This is compatible with exact periodic state recurrence and with the existing Activated History
Orientation theorem.
