# HOME T1221–T1238 — Can the Eight-State Receptor Also Supply Pre-UPO?

## Candidate occurrence

The same molecular receptor supports experimentally resolved ultrafast photophysical events.

Selective porphyrin excitation can produce charge separation/recombination or other
excited-state pathways depending on the static molecular context.

This is a real same-bearer occurrence in `H_occ`.

## Why that is not yet Pre-UPO

A complete optical excitation-relaxation cycle may return the retained bearer state to its
starting configuration.

Therefore:

`physical occurrence != automatically non-idempotent retained action`.

This is exactly the HOME distinction between occurrence-resolved history and the physical
action quotient.

One may try to define the absorption/excitation subevent alone.  Intermediate states are
physically witnessable, but the cut must be justified as a stable physical action boundary rather
than chosen from ultrafast timing convenience.

## Across the eight static contexts

The same optical trigger does not obviously induce the same bearer action in every cube state.
The photophysical pathways differ with the molecular configuration.

A common positive action could still emerge after quotienting context-specific zero-grade
dressing, but that is an alignment result to be tested, not assumed.

## Best experiment

1. establish/freeze the eight static contexts;
2. apply one fixed optical protocol to every context;
3. reconstruct intermediate and terminal bearer response maps;
4. test whether the eight realized procedures descend to one common non-idempotent action
   class after declared zero-grade decorations are erased.

If yes, the same molecule would become the first serious `B3 + Pre-UPO` bench candidate.

Current status: static side strong; Pre-UPO remains open.
