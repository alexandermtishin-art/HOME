# HOME v76.1 control-ID provenance

The provisional reader v76 files used the labels T1353 (dead-time classification) and T1354 (anchor-drift envelopes). These labels conflict with the independent O3–O6 work, whose series begins at T1353. No scientific claim, variable, seed, numerical result, or frozen acceptance criterion has changed in this renaming.

| Old provisional label | HOME-only new label | File base |
|---|---|---|
| T1353 (provisional HOME reader only) | HOME-C01 | `tests/HOME_C01_C02_controls/home_c01_deadtime_classification` |
| T1354 (provisional HOME reader only) | HOME-C02 | `tests/HOME_C01_C02_controls/home_c02_anchor_drift_envelopes` |

The old original v76 ZIP remains separately preserved as an archival input. v76.1 JSON output differs from original JSON only in the suite display string. Original code is modified only in the same label. Reproduced controls must still equal the frozen numerical results.

## GitHub URL
This prepared package is not proof of a public GitHub upload. The author account is https://github.com/alexandermtishin-art; the dedicated repository URL and release tag must be confirmed when published. Do not invent or announce a HOME repository until it exists.
