# Reproducibility scope

`tests/T498_T848`: 22 historical runnable suites, with their original frozen outputs.
`tests/T849_T914`: 4 later runnable suites with their original frozen outputs.
`tests/HOME_C01_C02_controls`: dead-time classification (event-level simulation) and anchor–drift envelope check for Appendix A.2, each with frozen output.

Checks labeled PASS / NO-GO in scripts are internal mathematical/computational controls relative to their modeled assumptions; do not interpret them as an experimental realization.

Protocol files in `bench_protocols/` specify a future test design, controls, and reported synthetic outcomes where applicable. The named physical device has not met all strict HOME gates within the preserved materials.

Developments through T1352 are represented by the preprint and the included notes. Technical audits of earlier versions are provided on reasoned request.

The HOME-C01/C02 namespace replaces the two provisional v76 labels T1353/T1354, which collide with the independent O3 ledger. See `docs/CONTROL_ID_PROVENANCE.md`. All results are synthetic/formal.
