#!/usr/bin/env python3
"""Verify bundled hashes and rerun preserved HOME executable controls."""
from __future__ import annotations
import hashlib, json, pathlib, subprocess, sys, os, tempfile, shutil, argparse

ROOT = pathlib.Path(__file__).resolve().parent
manifest = ROOT / "MANIFEST_SHA256.txt"

def verify_hashes():
    errors = []
    count = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        sha, name = line.split("  ", 1)
        p = ROOT/name
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest() != sha:
            errors.append(name)
        count += 1
    actual = {str(p.relative_to(ROOT)).replace("\\","/") for p in ROOT.rglob("*")
              if p.is_file() and p.name != "MANIFEST_SHA256.txt"}
    recorded = {line.split("  ", 1)[1] for line in manifest.read_text(encoding="utf-8").splitlines()
                if line.strip()}
    errors += sorted(actual-recorded)
    print(f"Manifest: {count-len(errors)}/{count} confirmed")
    if errors: raise RuntimeError("Hash/membership mismatch: "+", ".join(errors[:10]))

def verify_runs():
    count = total = 0
    errors = []
    for group in ("T498_T848", "T849_T914", "HOME_C01_C02_controls"):
        folder = ROOT / "tests" / group
        for script in sorted(folder.glob("*.py")):
            expected_file = folder/(script.stem+"_results.json")
            if not expected_file.is_file():
                errors.append(f"Missing frozen output for {script.name}");continue
            try:
                with tempfile.TemporaryDirectory(prefix="home_check_") as tdir:
                    sandbox = pathlib.Path(tdir)/group
                    shutil.copytree(folder, sandbox)
                    runner = sandbox/script.name
                    result = subprocess.run([sys.executable, str(runner)],
                        cwd=str(sandbox), capture_output=True, text=True, timeout=120,
                        env={**os.environ, "PYTHONDONTWRITEBYTECODE":"1"})
                if result.returncode:
                    raise RuntimeError(result.stderr[:500])
                actual = json.loads(result.stdout)
                expected = json.loads(expected_file.read_text(encoding="utf-8"))
                if actual != expected: raise AssertionError("Frozen output mismatch")
                summary = actual["summary"]
                n = int(summary["total"])
                if int(summary["passed"])!=n: raise AssertionError("Failed control")
                count+=1; total+=n
                print(f"PASS: {script.name}: {n}/{n}")
            except Exception as exc:
                errors.append(f"{script.name}: {exc}")
    if errors: raise RuntimeError("; ".join(errors))
    print(f"RESULT: {count} suites; {total}/{total} controls match frozen outputs")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify HOME v76.1 controls and SHA-256 manifest")
    parser.add_argument("--hash-only", action="store_true", help="Check only manifest and file membership")
    parser.add_argument("--new-only", action="store_true", help="Run only HOME-C01/C02, after manifest verification")
    args = parser.parse_args()
    verify_hashes()
    if args.new_only:
        folder = ROOT / 'tests' / 'HOME_C01_C02_controls'
        total = 0
        for script in sorted(folder.glob('*.py')):
            result = subprocess.run([sys.executable,str(script)],cwd=str(folder),capture_output=True,text=True,timeout=120,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"})
            if result.returncode: raise RuntimeError(result.stderr[:700])
            actual=json.loads(result.stdout)
            expected=json.loads((folder/(script.stem+'_results.json')).read_text(encoding='utf-8'))
            if actual!=expected: raise RuntimeError('Mismatch: '+script.name)
            n=actual['summary']['total']
            if actual['summary']['passed']!=n:raise RuntimeError('Failed control: '+script.name)
            total+=n
            print(f'PASS: {script.name}: {n}/{n}')
        print(f'NEW CONTROL RESULT: {total}/{total}')
    elif not args.hash_only:
        verify_runs()
