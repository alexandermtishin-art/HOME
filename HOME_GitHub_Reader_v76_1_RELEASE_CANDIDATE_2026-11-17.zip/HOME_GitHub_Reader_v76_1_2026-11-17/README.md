# HOME — Minimal Physical Object and Multiform Objecthood
## Reader and reproducibility package · 17 November 2026 (v76.1 release candidate)

**Manuscript:** `docs/HOME_v76_1_PREPRINT_2026-11-17.docx`, the full preprint text of the HOME programme.

**Scope.** This repository covers HOME's carrier and lineage structure, contextual response, occurrence histories, multiform access, apparatus descent, and the empirical HOME-gated candidate tests, together with the executable controls and bench protocols cited in the manuscript. Technical audits of earlier versions are not part of this release and are provided on reasoned request to tishin@amtc.org.

## Reading order

1. `docs/HOME_v76_1_PREPRINT_2026-11-17.docx`: the main scientific argument and its conditional results.
2. `docs/HOME_v75_POST_FREEZE_CLARIFICATIONS.md`: provenance note for the exact-support correction integrated into v76.1 §§4.3.1 and 12.13.
3. `bench_protocols/`: pre-specified, preregistration-ready B3/Pre-UPO protocols, frozen readout and stimulus controls.
4. `technical_notes/`: selected controls and counterexamples necessary to interpret the experimental frontier.
5. `tests/`: original computational implementations and frozen JSON results.

## What the tests show

- 22 executable historical suites from T498–T848: **345 / 345** controls reproduced against their archived outputs.
- Four further executable HOME suites from T849–T914: **66 / 66** controls reproduced against their archived outputs.
- Two further suites accompany v76: the dead-time classification (HOME-C01, 7/7 controls, event-level simulation) and the anchor–drift envelope bound of Appendix A.2 (HOME-C02, 2/2 controls, 2000 randomized trials).
- Total: **420 / 420** computational controls. These are formal/synthetic/code-consistency tests, **not** 420 empirical confirmations of HOME.
- T915–T1352 are represented mainly by original scientific notes, the v76 preprint, and laboratory protocols. The T1293–T1312 JSON matrix is a protocol/check record; it is not counted as another independent executable suite.
- Historical tests before T393 are primarily mathematical/documentary checks, not a lost series of Python scripts.

## Re-run

Requires Python 3 and NumPy for the bundled synthetic suites (run `python -m pip install numpy` if needed); verification and archive management otherwise use the standard library. Individual historical suites retain their original environment assumptions.

```bash
python verify_bundle.py
```

The verifier checks the release file manifest and reruns each included Python suite, comparing parsed JSON with the corresponding frozen JSON result. For a fast integrity-only check use `python verify_bundle.py --hash-only`; for the two newest suites use `python verify_bundle.py --new-only`.

## Scientific boundaries

- No claim that strict B3 + same-bearer Pre-UPO has already been physically demonstrated for the selected molecular candidate.
- No assertion that a numerical energy coupling or unique physical dynamics follows from HOME Core.
- No claim that exact operational support automatically determines a unique one-layer interaction structure.
- Earlier manuscript versions and audits are retained in a separate research archive. This package is a release candidate, not evidence of an already published HOME GitHub repository.


## Public repository link
Author GitHub profile: https://github.com/alexandermtishin-art.
A dedicated HOME repository URL and immutable release/tag must be added upon publication. Do not cite this prepared local ZIP as if it were already deposited on GitHub.

## Control-ID namespace
The separate post-freeze HOME controls are HOME-C01 and HOME-C02. Original provisional v76 labels T1353/T1354 were reassigned because T1353 onward belongs to the independent O3 manuscript. See `docs/CONTROL_ID_PROVENANCE.md`.
